package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderType
import com.example.data.model.BillingConfig
import com.example.ui.theme.Charcoal
import com.example.ui.theme.CharcoalMuted
import com.example.ui.theme.ChiyaInputTextStyle
import com.example.ui.theme.Cream
import com.example.ui.theme.DeepGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.TeaGreen
import com.example.ui.theme.Terracotta
import com.example.ui.theme.WarmWhite
import com.example.ui.theme.WoodBrown
import com.example.ui.theme.chiyaTextFieldColors
import com.example.ui.viewmodel.ChiyaViewModel

@Composable
fun CheckoutScreen(
    viewModel: ChiyaViewModel,
    onBackToCart: () -> Unit,
    onOrderPlaced: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val name by viewModel.customerName.collectAsState()
    val phone by viewModel.customerPhone.collectAsState()
    val type by viewModel.orderType.collectAsState()
    val table by viewModel.tableNumber.collectAsState()
    val pickupTime by viewModel.pickupTime.collectAsState()
    val subtotal by viewModel.cartSubtotal.collectAsState()
    val isSubmitting by viewModel.isSubmittingOrder.collectAsState()
    val orderError by viewModel.orderErrorMessage.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Cream)
    ) {
        // Top Header
        Surface(
            color = DeepGreen,
            contentColor = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackToCart,
                    modifier = Modifier.testTag("checkout_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = "Checkout & Details",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = Color.White
                )
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Customer Details Card
            Card(
                colors = CardDefaults.cardColors(containerColor = WarmWhite),
                shape = RoundedCornerShape(20.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Your Contact Details",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = Charcoal
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = name,
                        onValueChange = { viewModel.customerName.value = it },
                        label = { Text("Customer Name") },
                        placeholder = { Text("e.g. Sujan Shrestha") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = DeepGreen) },
                        singleLine = true,
                        textStyle = ChiyaInputTextStyle,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Words,
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Next
                        ),
                        colors = chiyaTextFieldColors(),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("customer_name_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { input ->
                            // Allow phone digits and symbols
                            if (input.all { it.isDigit() || it == '+' || it == '-' || it == ' ' }) {
                                viewModel.customerPhone.value = input
                            }
                        },
                        label = { Text("Phone Number") },
                        placeholder = { Text("e.g. 9800000000") },
                        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = DeepGreen) },
                        singleLine = true,
                        textStyle = ChiyaInputTextStyle,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Phone,
                            imeAction = if (type == OrderType.DINE_IN) ImeAction.Next else ImeAction.Done
                        ),
                        colors = chiyaTextFieldColors(),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("customer_phone_input")
                    )
                }
            }

            // Order Type Card
            Card(
                colors = CardDefaults.cardColors(containerColor = WarmWhite),
                shape = RoundedCornerShape(20.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Order Type",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = Charcoal
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Dine-in or Pickup Choice
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (type == OrderType.DINE_IN) Cream else WarmWhite)
                                .border(
                                    width = if (type == OrderType.DINE_IN) 2.dp else 1.dp,
                                    color = if (type == OrderType.DINE_IN) DeepGreen else SurfaceBorder,
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .clickable { viewModel.orderType.value = OrderType.DINE_IN }
                                .padding(14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Dine-in",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (type == OrderType.DINE_IN) DeepGreen else Charcoal
                                )
                                Text(
                                    text = "At Tea Room",
                                    fontSize = 11.sp,
                                    color = CharcoalMuted
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (type == OrderType.PICKUP) Cream else WarmWhite)
                                .border(
                                    width = if (type == OrderType.PICKUP) 2.dp else 1.dp,
                                    color = if (type == OrderType.PICKUP) DeepGreen else SurfaceBorder,
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .clickable { viewModel.orderType.value = OrderType.PICKUP }
                                .padding(14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Takeaway",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (type == OrderType.PICKUP) DeepGreen else Charcoal
                                )
                                Text(
                                    text = "Self Pickup",
                                    fontSize = 11.sp,
                                    color = CharcoalMuted
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (type == OrderType.DINE_IN) {
                        OutlinedTextField(
                            value = table,
                            onValueChange = { input ->
                                // Enforce numeric-only input (digits only)
                                if (input.all { it.isDigit() }) {
                                    viewModel.tableNumber.value = input
                                }
                            },
                            label = { Text("Table Number") },
                            placeholder = { Text("e.g. Table No. 3") },
                            singleLine = true,
                            textStyle = ChiyaInputTextStyle,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Done
                            ),
                            colors = chiyaTextFieldColors(),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("table_number_input")
                        )
                    } else {
                        OutlinedTextField(
                            value = pickupTime,
                            onValueChange = { viewModel.pickupTime.value = it },
                            label = { Text("Estimated Pickup Time") },
                            placeholder = { Text("e.g. In 15 mins / 4:30 PM") },
                            singleLine = true,
                            textStyle = ChiyaInputTextStyle,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.Done
                            ),
                            colors = chiyaTextFieldColors(),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("pickup_time_input")
                        )
                    }
                }
            }

            // Payment Option Card
            Card(
                colors = CardDefaults.cardColors(containerColor = WarmWhite),
                shape = RoundedCornerShape(20.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = WoodBrown
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Payment Method",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            color = Charcoal
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Cream)
                            .padding(14.dp)
                    ) {
                        Column {
                            Text(
                                text = "Pay at Counter (Cash / QR)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = DeepGreen
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Show your order confirmation screen to the staff when paying at the tea room counter.",
                                fontSize = 13.sp,
                                color = CharcoalMuted
                            )
                        }
                    }

                    // TODO: Payment Gateway Integration (Khalti / eSewa)
                    /*
                     * TODO: Digital Wallet / Online Payment Integration
                     * To add Khalti or eSewa integration in the future:
                     * 1. Add Khalti/eSewa Android SDK dependencies in build.gradle.kts
                     * 2. Initialize payment merchant keys in secrets / environment config
                     * 3. Add a radio button option for 'Khalti / eSewa Online Payment'
                     * 4. Call payment API trigger here before inserting OrderEntity into local DB.
                     */
                }
            }

            if (orderError != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Terracotta.copy(alpha = 0.1f)),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Terracotta)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⚠️ $orderError",
                            color = Terracotta,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Submit Button Container
        Surface(
            color = WarmWhite,
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                val discount = BillingConfig.DEFAULT_DISCOUNT.coerceIn(0.0, subtotal)
                val taxable = (subtotal - discount).coerceAtLeast(0.0)
                val tax = taxable * BillingConfig.VAT_RATE
                val serviceCharge = taxable * BillingConfig.SERVICE_CHARGE_RATE
                val grandTotal = taxable + tax + serviceCharge

                BillingSummaryRow("Subtotal", subtotal)
                if (discount > 0.0) BillingSummaryRow("Discount", -discount)
                BillingSummaryRow("VAT (${(BillingConfig.VAT_RATE * 100).toInt()}%)", tax)
                if (serviceCharge > 0.0) BillingSummaryRow("Service charge", serviceCharge)

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 8.dp),
                    color = SurfaceBorder
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Total Amount", fontSize = 14.sp, color = CharcoalMuted)
                    Text(
                        text = "NPR ${grandTotal.toInt()}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = DeepGreen
                    )
                }

                Button(
                    onClick = {
                        viewModel.placeOrder { orderId ->
                            onOrderPlaced(orderId)
                        }
                    },
                    enabled = !isSubmitting,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DeepGreen,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("submit_order_button")
                ) {
                    Text(
                        text = if (isSubmitting) "Verifying & Placing Order..." else "Confirm & Submit Order",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun BillingSummaryRow(label: String, amount: Double) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 13.sp, color = CharcoalMuted)
        Text(
            text = "NPR ${amount.toInt()}",
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = Charcoal
        )
    }
}

