package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.MenuItem
import com.example.data.model.MomoVariant
import com.example.ui.theme.Charcoal
import com.example.ui.theme.CharcoalMuted
import com.example.ui.theme.Cream
import com.example.ui.theme.DeepGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.TeaGreen
import com.example.ui.theme.Terracotta
import com.example.ui.theme.WarmWhite

@Composable
fun MomoVariantDialog(
    item: MenuItem,
    onDismiss: () -> Unit,
    onAddToCart: (MenuItem, String, Double) -> Unit
) {
    val variants = item.variants ?: emptyList()
    var selectedVariant by remember {
        mutableStateOf(variants.firstOrNull() ?: MomoVariant("Steam", item.price))
    }

    val configuration = LocalConfiguration.current
    val maxModalHeight = (configuration.screenHeightDp * 0.88f).dp
    val listState = rememberLazyListState()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = WarmWhite,
            tonalElevation = 8.dp,
            shadowElevation = 12.dp,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .heightIn(max = maxModalHeight)
                .testTag("momo_variant_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = maxModalHeight)
            ) {
                // 1. Fixed / Sticky Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = item.name,
                                fontSize = 19.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Serif,
                                color = Charcoal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (item.nepaliName != null) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "(${item.nepaliName})",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = DeepGreen
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Choose your preferred preparation style",
                            fontSize = 12.sp,
                            color = CharcoalMuted
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Cream)
                            .testTag("close_momo_dialog_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Charcoal,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                HorizontalDivider(
                    color = SurfaceBorder,
                    thickness = 1.dp
                )

                // 2. Scrollable Variant List Area (Only this area scrolls)
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .fillMaxWidth()
                        .testTag("momo_variants_scroll_list")
                ) {
                    items(variants, key = { it.name }) { variant ->
                        val isSelected = selectedVariant.name == variant.name

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isSelected) Cream else WarmWhite)
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) DeepGreen else SurfaceBorder,
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .clickable { selectedVariant = variant }
                                .padding(horizontal = 14.dp, vertical = 12.dp)
                                .testTag("momo_variant_option_${variant.name.lowercase()}"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { selectedVariant = variant },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = DeepGreen,
                                        unselectedColor = CharcoalMuted
                                    )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "${variant.name} Momo",
                                        fontSize = 15.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = Charcoal
                                    )
                                    val desc = when (variant.name) {
                                        "Steam" -> "Classic steamed dumplings with dipping chutneys"
                                        "Fry" -> "Golden pan-crisped dumplings"
                                        "Jhol" -> "Submerged in rich, tangy sesame chili broth"
                                        "Kothe" -> "Half-steamed, half-pan crisped bottoms"
                                        "Sadeko" -> "Spiced tossed with fresh garlic, onions & coriander"
                                        else -> "Fresh Himalayan style momo"
                                    }
                                    Text(
                                        text = desc,
                                        fontSize = 11.sp,
                                        color = CharcoalMuted,
                                        lineHeight = 15.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Text(
                                text = "NPR ${variant.price.toInt()}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Serif,
                                color = DeepGreen
                            )
                        }
                    }
                }

                HorizontalDivider(
                    color = SurfaceBorder,
                    thickness = 1.dp
                )

                // 3. Fixed / Sticky Footer with Selection Summary and Add Button
                Surface(
                    color = WarmWhite,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Selected: ${selectedVariant.name} Momo",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = DeepGreen,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "NPR ${selectedVariant.price.toInt()}",
                                fontSize = 19.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Serif,
                                color = DeepGreen
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Button(
                            onClick = {
                                onAddToCart(item, selectedVariant.name, selectedVariant.price)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DeepGreen,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .height(46.dp)
                                .testTag("add_momo_variant_to_cart_button")
                        ) {
                            Text(
                                text = "Add to Cart",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
