package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ChiyaDatabase
import com.example.data.local.OrderEntity
import com.example.data.model.CartItem
import com.example.data.model.MenuItem
import com.example.data.model.OrderItemSummary
import com.example.data.model.OrderType
import com.example.data.repository.AdminAuthRepository
import com.example.data.repository.CartRepository
import com.example.data.repository.MenuRepository
import com.example.data.repository.OrderRepository
import com.example.service.ChatMessage
import com.example.service.ChiyaGeminiChatService
import com.example.service.MessageSender
import com.example.util.OrderNotificationHelper
import com.example.util.SecurityUtils
import com.example.util.SlidingWindowRateLimiter
import com.example.util.SoundHelper
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChiyaViewModel(application: Application) : AndroidViewModel(application) {

    private val db = ChiyaDatabase.getDatabase(application)
    private val cartRepository = CartRepository(db.cartDao())
    val menuRepository = MenuRepository()
    val orderRepository = OrderRepository(db.orderDao(), cartRepository, menuRepository)
    val adminAuthRepository = AdminAuthRepository(application)
    private val firestoreOrderService = com.example.data.remote.FirestoreOrderService()
    private val geminiChatService = ChiyaGeminiChatService(menuRepository)

    // AI Assistant Chat State
    private val _isAiChatOpen = MutableStateFlow(false)
    val isAiChatOpen: StateFlow<Boolean> = _isAiChatOpen.asStateFlow()

    private val _isAiTyping = MutableStateFlow(false)
    val isAiTyping: StateFlow<Boolean> = _isAiTyping.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = MessageSender.AI,
                text = "Namaste! Welcome to Chiya San 😊 I'm your tea room assistant. Looking for recommendations, momos, traditional chiyas, or help with your order?"
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val sharedPrefs = application.getSharedPreferences("chiya_san_secure_prefs", Context.MODE_PRIVATE)

    // Supabase Admin Authentication State
    val isAdminLoggedIn: StateFlow<Boolean> = adminAuthRepository.isAuthenticatedAdmin
    val adminAuthError: StateFlow<String?> = adminAuthRepository.authError
    val isAdminAuthLoading: StateFlow<Boolean> = adminAuthRepository.isLoading
    val currentAdminSession: StateFlow<com.example.data.remote.SupabaseSession?> = adminAuthRepository.currentSession

    private val _revealCustomerPhone = MutableStateFlow(false)
    val revealCustomerPhone: StateFlow<Boolean> = _revealCustomerPhone.asStateFlow()

    // Notification State
    private val _notificationsEnabled = MutableStateFlow(sharedPrefs.getBoolean("notifications_enabled", true))
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    // FCM Token state
    private val _fcmToken = MutableStateFlow<String?>(null)
    val fcmToken: StateFlow<String?> = _fcmToken.asStateFlow()

    private val _unseenOrderIds = MutableStateFlow<Set<String>>(emptySet())
    val unseenOrderIds: StateFlow<Set<String>> = _unseenOrderIds.asStateFlow()

    val unseenOrderCount: StateFlow<Int> = _unseenOrderIds.map { it.size }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    // Prominent alert for new order
    private val _latestOrderAlert = MutableStateFlow<OrderEntity?>(null)
    val latestOrderAlert: StateFlow<OrderEntity?> = _latestOrderAlert.asStateFlow()

    // Selected order for detailed modal or view in Admin
    private val _selectedAdminOrder = MutableStateFlow<OrderEntity?>(null)
    val selectedAdminOrder: StateFlow<OrderEntity?> = _selectedAdminOrder.asStateFlow()

    // Admin filter
    private val _adminStatusFilter = MutableStateFlow("All")
    val adminStatusFilter: StateFlow<String> = _adminStatusFilter.asStateFlow()

    // Track known order IDs to prevent replaying sound on app start or re-render
    private val knownOrderIds = mutableSetOf<String>()
    private var isInitialOrdersLoad = true

    // Filter & Search
    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val filteredMenuItems: StateFlow<List<MenuItem>> = combine(
        _selectedCategory,
        _searchQuery
    ) { category, query ->
        menuRepository.getItemsByCategory(category, query)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = menuRepository.menuItems
    )

    // Variant & Flavour Modals
    private val _activeMomoItem = MutableStateFlow<MenuItem?>(null)
    val activeMomoItem: StateFlow<MenuItem?> = _activeMomoItem.asStateFlow()

    private val _activeHookahItem = MutableStateFlow<MenuItem?>(null)
    val activeHookahItem: StateFlow<MenuItem?> = _activeHookahItem.asStateFlow()

    // Cart
    val cartItems: StateFlow<List<CartItem>> = cartRepository.cartItems.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = emptyList()
    )

    val cartTotalCount: StateFlow<Int> = cartItems.map { items ->
        items.sumOf { it.quantity }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = 0
    )

    val cartSubtotal: StateFlow<Double> = cartItems.map { items ->
        items.sumOf { it.totalPrice }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = 0.0
    )

    // Checkout Form State
    val customerName = MutableStateFlow("")
    val customerPhone = MutableStateFlow("")
    val orderType = MutableStateFlow(OrderType.DINE_IN)
    val tableNumber = MutableStateFlow("")
    val pickupTime = MutableStateFlow("In 15 mins")

    // Order Submission States
    private val _isSubmittingOrder = MutableStateFlow(false)
    val isSubmittingOrder: StateFlow<Boolean> = _isSubmittingOrder.asStateFlow()

    private val _orderErrorMessage = MutableStateFlow<String?>(null)
    val orderErrorMessage: StateFlow<String?> = _orderErrorMessage.asStateFlow()

    // Confirmation State
    private val _confirmedOrderId = MutableStateFlow<String?>(null)
    val confirmedOrderId: StateFlow<String?> = _confirmedOrderId.asStateFlow()

    // Customer Session Owned Orders (for client privacy & anti-IDOR in history view)
    private val _customerPlacedOrderIds = MutableStateFlow<Set<String>>(
        sharedPrefs.getStringSet("customer_placed_order_ids", emptySet()) ?: emptySet()
    )
    val customerPlacedOrderIds: StateFlow<Set<String>> = _customerPlacedOrderIds.asStateFlow()

    // Order History: All orders from database
    val pastOrders: StateFlow<List<OrderEntity>> = orderRepository.allOrders.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = emptyList()
    )

    // Customer specific orders (filtered by session tokens for non-admin)
    val customerPastOrders: StateFlow<List<OrderEntity>> = combine(
        orderRepository.allOrders,
        _customerPlacedOrderIds,
        isAdminLoggedIn
    ) { all: List<OrderEntity>, ownedIds: Set<String>, isAdmin: Boolean ->
        if (isAdmin) {
            all
        } else {
            all.filter { it.orderId in ownedIds }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = emptyList()
    )

    init {
        OrderNotificationHelper.createNotificationChannel(application)
        initFirebaseMessaging()
        observeRealtimeOrders()
        observeSupabaseCloudOrders()
        observeFirestoreCloudOrders()
        syncMenuItemsFromSupabase()
    }

    private fun syncMenuItemsFromSupabase() {
        viewModelScope.launch {
            try {
                val supabaseOrderService = com.example.data.remote.SupabaseOrderService()
                val result = supabaseOrderService.fetchMenuItems()
                if (result.isSuccess) {
                    val items = result.getOrNull()
                    if (!items.isNullOrEmpty()) {
                        menuRepository.updateMenuItems(items)
                    }
                }
            } catch (e: Exception) {
                // Keep local defaults
            }
        }
    }

    private fun observeSupabaseCloudOrders() {
        viewModelScope.launch {
            try {
                orderRepository.getSupabaseOrdersFlow {
                    adminAuthRepository.currentSession.value?.accessToken
                }.collect { remoteOrders ->
                    if (remoteOrders.isNotEmpty()) {
                        orderRepository.syncOrdersFromCloud(remoteOrders)
                    }
                }
            } catch (e: Exception) {
                // Supabase realtime fallback
            }
        }
    }

    private fun initFirebaseMessaging() {
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val token = task.result
                    _fcmToken.value = token
                    viewModelScope.launch {
                        firestoreOrderService.saveAdminFcmToken(token)
                    }
                }
            }
        } catch (t: Throwable) {
            // Firebase initialized or running in local test mode
        }
    }

    /**
     * Send Phone OTP verification code via Supabase GoTrue Auth SMS
     */
    fun sendAdminPhoneOtp(
        phoneNumber: String,
        onResult: (Result<String>) -> Unit = {}
    ) {
        viewModelScope.launch {
            val result = adminAuthRepository.sendPhoneOtp(phoneNumber)
            onResult(result)
        }
    }

    /**
     * Verify Phone OTP code with Supabase Auth and establish Admin session
     */
    fun verifyAdminPhoneOtp(
        phoneNumber: String,
        otpCode: String,
        onSuccess: () -> Unit = {},
        onResult: (Result<com.example.data.remote.SupabaseUser>) -> Unit = {}
    ) {
        viewModelScope.launch {
            val token = _fcmToken.value
            val result = adminAuthRepository.verifyPhoneOtp(phoneNumber, otpCode, token)
            onResult(result)
            if (result.isSuccess && isAdminLoggedIn.value) {
                onSuccess()
            }
        }
    }

    /**
     * Signs out from Supabase Auth and destroys session state
     */
    fun logoutAdmin() {
        viewModelScope.launch {
            adminAuthRepository.signOut()
            _revealCustomerPhone.value = false
            _selectedAdminOrder.value = null
        }
    }

    fun clearAdminAuthError() {
        adminAuthRepository.clearError()
    }

    fun toggleCustomerPhoneVisibility() {
        if (isAdminLoggedIn.value) {
            _revealCustomerPhone.value = !_revealCustomerPhone.value
        }
    }

    private fun observeFirestoreCloudOrders() {
        viewModelScope.launch {
            try {
                orderRepository.firestoreOrdersFlow.collect { cloudOrders ->
                    if (cloudOrders.isNotEmpty()) {
                        orderRepository.syncOrdersFromCloud(cloudOrders)
                    }
                }
            } catch (e: Exception) {
                // Firestore offline fallback
            }
        }
    }

    private fun observeRealtimeOrders() {
        viewModelScope.launch {
            orderRepository.allOrders.collect { orders ->
                if (isInitialOrdersLoad) {
                    knownOrderIds.addAll(orders.map { it.orderId })
                    isInitialOrdersLoad = false
                } else {
                    val newOrders = orders.filter { it.orderId !in knownOrderIds }
                    if (newOrders.isNotEmpty()) {
                        for (newOrder in newOrders) {
                            knownOrderIds.add(newOrder.orderId)
                            _unseenOrderIds.value = _unseenOrderIds.value + newOrder.orderId

                            // Play audio notification
                            SoundHelper.playOrderChime(getApplication())

                            // Trigger in-app banner
                            _latestOrderAlert.value = newOrder

                            // Trigger system notification if enabled
                            if (_notificationsEnabled.value) {
                                val items = parseOrderItems(newOrder.itemsSummaryJson)
                                OrderNotificationHelper.showNewOrderPushNotification(
                                    context = getApplication(),
                                    orderId = newOrder.orderId,
                                    customerName = newOrder.customerName,
                                    subtotal = newOrder.subtotal,
                                    itemsList = items,
                                    orderType = newOrder.orderType,
                                    tableOrPickup = newOrder.tableNumber ?: newOrder.pickupTime
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    fun selectAdminOrderById(orderId: String) {
        viewModelScope.launch {
            val order = pastOrders.value.find { it.orderId.equals(orderId, ignoreCase = true) }
                ?: db.orderDao().getOrderById(orderId)
            if (order != null) {
                _selectedAdminOrder.value = order
                markOrderAsSeen(order.orderId)
            }
        }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        _notificationsEnabled.value = enabled
        sharedPrefs.edit().putBoolean("notifications_enabled", enabled).apply()
    }

    fun markOrderAsSeen(orderId: String) {
        _unseenOrderIds.value = _unseenOrderIds.value - orderId
        if (_latestOrderAlert.value?.orderId == orderId) {
            _latestOrderAlert.value = null
        }
    }

    fun markAllOrdersAsSeen() {
        _unseenOrderIds.value = emptySet()
        _latestOrderAlert.value = null
    }

    fun dismissLatestAlert() {
        _latestOrderAlert.value = null
    }

    fun selectAdminOrder(order: OrderEntity?) {
        _selectedAdminOrder.value = order
        if (order != null) {
            markOrderAsSeen(order.orderId)
        }
    }

    fun setAdminStatusFilter(status: String) {
        _adminStatusFilter.value = status
    }

    fun updateOrderStatus(orderId: String, newStatus: String) {
        viewModelScope.launch {
            val token = adminAuthRepository.currentSession.value?.accessToken
            val result = orderRepository.updateOrderStatus(
                orderId = orderId,
                newStatus = newStatus,
                isAuthorizedAdmin = isAdminLoggedIn.value,
                adminToken = token
            )
            if (result.isSuccess) {
                if (_selectedAdminOrder.value?.orderId == orderId) {
                    _selectedAdminOrder.value = _selectedAdminOrder.value?.copy(status = newStatus)
                }
            }
        }
    }


    fun updatePaymentStatus(orderId: String, newStatus: String) {
        viewModelScope.launch {
            val token = adminAuthRepository.currentSession.value?.accessToken
            val result = orderRepository.updatePaymentStatus(
                orderId = orderId,
                newPaymentStatus = newStatus,
                isAuthorizedAdmin = isAdminLoggedIn.value,
                adminToken = token
            )
            if (result.isSuccess) {
                _selectedAdminOrder.value = _selectedAdminOrder.value?.copy(paymentStatus = newStatus)
            }
        }
    }

    fun cancelOrder(orderId: String) {
        viewModelScope.launch {
            val token = adminAuthRepository.currentSession.value?.accessToken
            val result = orderRepository.deleteOrder(
                orderId = orderId,
                isAuthorizedAdmin = isAdminLoggedIn.value,
                adminToken = token
            )
            if (result.isSuccess) {
                _selectedAdminOrder.value = null
                _unseenOrderIds.value = _unseenOrderIds.value - orderId
            }
        }
    }

    fun playChimeSound() {
        SoundHelper.playOrderChime(getApplication())
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun openMomoSelector(item: MenuItem) {
        _activeMomoItem.value = item
    }

    fun dismissMomoSelector() {
        _activeMomoItem.value = null
    }

    fun openHookahSelector(item: MenuItem) {
        _activeHookahItem.value = item
    }

    fun dismissHookahSelector() {
        _activeHookahItem.value = null
    }

    fun addToCartDirect(item: MenuItem) {
        viewModelScope.launch {
            cartRepository.addToCart(
                menuItemId = item.id,
                name = item.name,
                category = item.category,
                variant = null,
                flavour = null,
                unitPrice = item.price,
                quantity = 1
            )
        }
    }

    fun addMomoToCart(item: MenuItem, variantName: String, variantPrice: Double) {
        viewModelScope.launch {
            cartRepository.addToCart(
                menuItemId = item.id,
                name = item.name,
                category = item.category,
                variant = variantName,
                flavour = null,
                unitPrice = variantPrice,
                quantity = 1
            )
            dismissMomoSelector()
        }
    }

    fun addHookahToCart(item: MenuItem, flavourName: String, price: Double) {
        viewModelScope.launch {
            cartRepository.addToCart(
                menuItemId = item.id,
                name = item.name,
                category = item.category,
                variant = null,
                flavour = flavourName,
                unitPrice = price,
                quantity = 1
            )
            dismissHookahSelector()
        }
    }

    fun updateCartQuantity(cartItem: CartItem, newQty: Int) {
        viewModelScope.launch {
            cartRepository.updateCartItemQuantity(cartItem, newQty)
        }
    }

    fun removeCartItem(cartItemId: Int) {
        viewModelScope.launch {
            cartRepository.removeCartItem(cartItemId)
        }
    }

    fun clearOrderError() {
        _orderErrorMessage.value = null
    }

    fun placeOrder(onSuccess: (String) -> Unit) {
        val currentCart = cartItems.value
        if (currentCart.isEmpty()) {
            _orderErrorMessage.value = "Your cart is empty. Please add items to order."
            return
        }

        val name = customerName.value
        val phone = customerPhone.value
        val type = if (orderType.value == OrderType.DINE_IN) "Dine-in" else "Pickup"
        val table = if (orderType.value == OrderType.DINE_IN) tableNumber.value else null
        val pickup = if (orderType.value == OrderType.PICKUP) pickupTime.value else null
        val clientTotal = cartSubtotal.value

        _isSubmittingOrder.value = true
        _orderErrorMessage.value = null

        viewModelScope.launch {
            val result = orderRepository.placeOrder(
                customerName = name,
                customerPhone = phone,
                orderType = type,
                tableNumber = table,
                pickupTime = pickup,
                cartItems = currentCart,
                clientSubtotal = clientTotal
            )

            _isSubmittingOrder.value = false

            result.onSuccess { placementResult ->
                // Register placed order ID in customer session preference
                val updatedOwnedIds = _customerPlacedOrderIds.value + placementResult.orderId
                _customerPlacedOrderIds.value = updatedOwnedIds
                sharedPrefs.edit().putStringSet("customer_placed_order_ids", updatedOwnedIds).apply()

                // Mark order as unseen for admin badge
                knownOrderIds.add(placementResult.orderId)
                _unseenOrderIds.value = _unseenOrderIds.value + placementResult.orderId

                // Immediately trigger admin push notification (Facebook style popup) and chime
                val itemsSummaryList = currentCart.map {
                    OrderItemSummary(
                        name = it.name,
                        variant = it.selectedVariant,
                        flavour = it.selectedFlavour,
                        unitPrice = it.unitPrice,
                        quantity = it.quantity
                    )
                }
                OrderNotificationHelper.showNewOrderPushNotification(
                    context = getApplication(),
                    orderId = placementResult.orderId,
                    customerName = name,
                    subtotal = placementResult.total,
                    itemsList = itemsSummaryList,
                    orderType = type,
                    tableOrPickup = table ?: pickup
                )
                SoundHelper.playOrderChime(getApplication())

                _confirmedOrderId.value = placementResult.orderId
                onSuccess(placementResult.orderId)
            }.onFailure { error ->
                _orderErrorMessage.value = error.message ?: "Failed to place order securely."
            }
        }
    }

    fun dismissConfirmation() {
        _confirmedOrderId.value = null
    }

    fun parseOrderItems(json: String): List<OrderItemSummary> {
        return orderRepository.parseOrderItems(json)
    }

    fun setAiChatOpen(isOpen: Boolean) {
        _isAiChatOpen.value = isOpen
    }

    fun sendUserChatMessage(messageText: String) {
        val clean = messageText.trim()
        if (clean.isBlank()) return

        val userMsg = ChatMessage(sender = MessageSender.USER, text = clean)
        val current = _chatMessages.value
        _chatMessages.value = current + userMsg
        _isAiTyping.value = true

        viewModelScope.launch {
            val responseResult = geminiChatService.sendMessage(
                history = current,
                userMessage = clean
            )
            _isAiTyping.value = false
            val aiReplyText = responseResult.getOrElse {
                "Sorry, I don't have confirmed information about that. Please check with the restaurant."
            }
            val aiMsg = ChatMessage(sender = MessageSender.AI, text = aiReplyText)
            _chatMessages.value = _chatMessages.value + aiMsg
        }
    }

    fun resetChat() {
        _chatMessages.value = listOf(
            ChatMessage(
                sender = MessageSender.AI,
                text = "Namaste! Welcome to Chiya San 😊 I'm your tea room assistant. Looking for recommendations, momos, traditional chiyas, or help with your order?"
            )
        )
    }
}

