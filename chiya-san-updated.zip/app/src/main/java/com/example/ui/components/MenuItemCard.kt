package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MenuItem
import com.example.ui.theme.Charcoal
import com.example.ui.theme.CharcoalMuted
import com.example.ui.theme.DeepGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.TeaGreen
import com.example.ui.theme.Terracotta
import com.example.ui.theme.WarmWhite
import com.example.ui.theme.WoodBrown

@Composable
fun MenuItemCard(
    item: MenuItem,
    onAddToCart: (MenuItem) -> Unit,
    onOpenMomoSelector: (MenuItem) -> Unit,
    onOpenHookahSelector: (MenuItem) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = WarmWhite),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("menu_item_card_${item.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = item.name,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            color = Charcoal
                        )
                        if (item.nepaliName != null) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "(${item.nepaliName})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = DeepGreen
                            )
                        }
                    }

                    if (item.unit != null) {
                        Text(
                            text = item.unit,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = WoodBrown,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }

                    if (!item.description.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = item.description,
                            fontSize = 13.sp,
                            color = CharcoalMuted,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Price Tag
                Column {
                    val priceText = when {
                        item.hasVariants && item.variants != null -> {
                            val min = item.variants.minOf { it.price }.toInt()
                            val max = item.variants.maxOf { it.price }.toInt()
                            "NPR $min – $max"
                        }
                        else -> "NPR ${item.price.toInt()}"
                    }

                    Text(
                        text = priceText,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = DeepGreen
                    )

                    if (item.hasVariants) {
                        Text(
                            text = "5 variants available",
                            fontSize = 11.sp,
                            color = Terracotta,
                            fontWeight = FontWeight.Medium
                        )
                    } else if (item.hasFlavours) {
                        Text(
                            text = "Choice of flavour",
                            fontSize = 11.sp,
                            color = WoodBrown,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Action Button
                when {
                    item.hasVariants -> {
                        Button(
                            onClick = { onOpenMomoSelector(item) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DeepGreen,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("select_variant_button_${item.id}")
                        ) {
                            Text("Select Variant", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    item.hasFlavours -> {
                        Button(
                            onClick = { onOpenHookahSelector(item) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DeepGreen,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("select_flavour_button_${item.id}")
                        ) {
                            Text("Select Flavour", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    else -> {
                        Button(
                            onClick = { onAddToCart(item) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DeepGreen,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("add_to_cart_button_${item.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add",
                                modifier = Modifier.padding(end = 4.dp)
                            )
                            Text("Add", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}
