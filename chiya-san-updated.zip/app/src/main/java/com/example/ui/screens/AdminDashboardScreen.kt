package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.example.data.local.OrderEntity
import com.example.ui.components.ChiyaSanAdminHeaderBrand
import com.example.ui.theme.CardHighlight
import com.example.ui.theme.Charcoal
import com.example.ui.theme.CharcoalMuted
import com.example.ui.theme.Cream
import com.example.ui.theme.DeepGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.TeaGreen
import com.example.ui.theme.Terracotta
import com.example.ui.theme.WarmWhite
import com.example.ui.theme.WoodBrown
import com.example.ui.viewmodel.ChiyaViewModel
import com.example.util.SecurityUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminDashboardScreen(
    viewModel: ChiyaViewModel,
    onLogout: () -> Unit = {},
    onBackToCustomerView: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isAdminLoggedIn by viewModel.isAdminLoggedIn.collectAsState()

    if (!isAdminLoggedIn) {
        AdminLoginScreen(
            viewModel = viewModel,
            onLoginSuccess = { /* Navigated to dashboard */ },
            onBackToCustomerView = onBackToCustomerView,
            modifier = modifier
        )
    } else {
        AdminDashboardContent(
            viewModel = viewModel,
            onLogout = onLogout,
            modifier = modifier
        )
    }
}

@Composable
fun AdminDashboardContent(
    viewModel: ChiyaViewModel,
    onLogout: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentSession by viewModel.currentAdminSession.collectAsState()
    val allOrders by viewModel.pastOrders.collectAsState()
    val unseenOrderIds by viewModel.unseenOrderIds.collectAsState()
    val unseenCount by viewModel.unseenOrderCount.collectAsState()
    val notificationsEnabled by viewModel.notificationsEnabled.collectAsState()
    val statusFilter by viewModel.adminStatusFilter.collectAsState()
    val selectedOrder by viewModel.selectedAdminOrder.collectAsState()
    val revealPhone by viewModel.revealCustomerPhone.collectAsState()

    // Permission launcher for Android 13+
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        viewModel.setNotificationsEnabled(isGranted)
    }

    val requestNotificationPermission = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val hasPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED

            if (!hasPermission) {
                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                viewModel.setNotificationsEnabled(true)
            }
        } else {
            viewModel.setNotificationsEnabled(true)
        }
    }

    // Filter orders
    val filteredOrders = remember(allOrders, statusFilter, unseenOrderIds) {
        when (statusFilter) {
            "Unseen" -> allOrders.filter { it.orderId in unseenOrderIds }
            "All" -> allOrders
            else -> allOrders.filter { it.status.contains(statusFilter, ignoreCase = true) }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Cream)
    ) {
        // Top Header with Chiya San Admin Logo
        Surface(
            color = DeepGreen,
            contentColor = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ChiyaSanAdminHeaderBrand(
                        subtitle = "Kitchen & Order Management"
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Test Sound Button
                        IconButton(
                            onClick = { viewModel.playChimeSound() },
                            modifier = Modifier.testTag("admin_test_sound_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Test Notification Chime",
                                tint = TeaGreen
                            )
                        }

                        // Logout Admin Button
                        IconButton(
                            onClick = {
                                viewModel.logoutAdmin()
                                onLogout()
                            },
                            modifier = Modifier.testTag("admin_logout_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Logout,
                                contentDescription = "Logout Admin",
                                tint = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Notification Status & Privacy Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Enable Notification Action Button
                    Button(
                        onClick = {
                            if (notificationsEnabled) {
                                viewModel.setNotificationsEnabled(false)
                            } else {
                                requestNotificationPermission()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (notificationsEnabled) TeaGreen else Terracotta,
                            contentColor = if (notificationsEnabled) DeepGreen else Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .testTag("enable_notifications_button")
                    ) {
                        Icon(
                            imageVector = if (notificationsEnabled) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (notificationsEnabled) "Alerts Active" else "Enable Alerts",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Privacy Mask / Unmask Toggle
                    OutlinedButton(
                        onClick = { viewModel.toggleCustomerPhoneVisibility() },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = ButtonDefaults.outlinedButtonBorder().copy(
                            brush = androidx.compose.ui.graphics.SolidColor(TeaGreen)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(40.dp)
                            .testTag("admin_privacy_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (revealPhone) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = TeaGreen
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (revealPhone) "Mask" else "Reveal",
                            fontSize = 11.sp,
                            color = TeaGreen
                        )
                    }

                    // Mark all seen button if there are unseen orders
                    if (unseenCount > 0) {
                        OutlinedButton(
                            onClick = { viewModel.markAllOrdersAsSeen() },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color.White
                            ),
                            border = ButtonDefaults.outlinedButtonBorder().copy(
                                brush = androidx.compose.ui.graphics.SolidColor(TeaGreen)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .height(40.dp)
                                .testTag("mark_all_seen_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DoneAll,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = TeaGreen
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Seen", fontSize = 11.sp, color = TeaGreen)
                        }
                    }
                }
            }
        }

        // Live Unseen Alert Banner
        if (unseenCount > 0) {
            Surface(
                color = Terracotta,
                contentColor = Color.White,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "🔔 $unseenCount New Order${if (unseenCount > 1) "s" else ""} Received",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    Text(
                        text = "Real-Time Kitchen Feed",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            }
        }

        // Filter Bar
        val filterOptions = listOf(
            "All" to "All (${allOrders.size})",
            "Unseen" to "Unseen ($unseenCount)",
            "New" to "New",
            "Accepted" to "Accepted",
            "Preparing" to "Preparing",
            "Ready" to "Ready",
            "Completed" to "Completed"
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(filterOptions) { (key, label) ->
                val selected = statusFilter == key
                FilterChip(
                    selected = selected,
                    onClick = { viewModel.setAdminStatusFilter(key) },
                    label = { Text(label, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = DeepGreen,
                        selectedLabelColor = Color.White,
                        containerColor = WarmWhite,
                        labelColor = Charcoal
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("admin_filter_$key")
                )
            }
        }

        // Orders List
        if (filteredOrders.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = null,
                        tint = CharcoalMuted,
                        modifier = Modifier.size(52.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (statusFilter == "Unseen") "No Unseen Orders" else "No Orders Found",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = Charcoal
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Orders placed by customers will appear here in real time with audio chimes and dispatch controls.",
                        fontSize = 12.sp,
                        color = CharcoalMuted,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        lineHeight = 16.sp
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .testTag("admin_orders_list")
            ) {
                items(filteredOrders, key = { it.orderId }) { order ->
                    val isUnseen = order.orderId in unseenOrderIds
                    AdminOrderCard(
                        order = order,
                        isUnseen = isUnseen,
                        revealPhone = revealPhone,
                        viewModel = viewModel,
                        onOpenDetails = { viewModel.selectAdminOrder(order) },
                        onMarkSeen = { viewModel.markOrderAsSeen(order.orderId) }
                    )
                }
            }
        }
    }

    // Order Details Dialog
    selectedOrder?.let { order ->
        AdminOrderDetailDialog(
            order = order,
            revealPhone = revealPhone,
            viewModel = viewModel,
            onDismiss = { viewModel.selectAdminOrder(null) },
            onStatusChange = { newStatus ->
                viewModel.updateOrderStatus(order.orderId, newStatus)
            },
            onPaymentStatusChange = { newPaymentStatus ->
                viewModel.updatePaymentStatus(order.orderId, newPaymentStatus)
            },
            onDeleteOrder = {
                viewModel.cancelOrder(order.orderId)
            }
        )
    }
}



@Composable
private fun BillingAdminRow(label: String, amount: Double) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.sp, color = CharcoalMuted)
        Text("NPR ${amount.toInt()}", fontSize = 12.sp, color = Charcoal)
    }
}

@Composable
fun AdminOrderCard(
    order: OrderEntity,
    isUnseen: Boolean,
    revealPhone: Boolean,
    viewModel: ChiyaViewModel,
    onOpenDetails: () -> Unit,
    onMarkSeen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val items = viewModel.parseOrderItems(order.itemsSummaryJson)
    val totalItemCount = items.sumOf { it.quantity }.coerceAtLeast(1)
    val sdf = SimpleDateFormat("hh:mm a • MMM dd", Locale.getDefault())
    val formattedTime = sdf.format(Date(order.timestamp))
    val displayPhone = if (revealPhone) order.customerPhone else SecurityUtils.maskPhoneNumber(order.customerPhone)

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isUnseen) CardHighlight else WarmWhite
        ),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isUnseen) 6.dp else 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = if (isUnseen) 2.dp else 1.dp,
                color = if (isUnseen) Terracotta else SurfaceBorder,
                shape = RoundedCornerShape(18.dp)
            )
            .testTag("admin_order_card_${order.orderId}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isUnseen) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Terracotta)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "NEW 🔔",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    Text(
                        text = order.orderId,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = DeepGreen
                    )
                }

                Text(
                    text = formattedTime,
                    fontSize = 11.sp,
                    color = CharcoalMuted
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Customer and Order Meta
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Customer: ${order.customerName}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Charcoal
                    )
                    Text(
                        text = "Phone: $displayPhone",
                        fontSize = 12.sp,
                        color = CharcoalMuted
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (order.orderType == "Dine-in") TeaGreen.copy(alpha = 0.35f) else WoodBrown.copy(alpha = 0.15f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (order.orderType == "Dine-in") "Table #${order.tableNumber ?: "?"}" else "Takeaway: ${order.pickupTime ?: "ASAP"}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (order.orderType == "Dine-in") DeepGreen else WoodBrown
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick items preview
            val previewText = items.joinToString(", ") { "${it.quantity}x ${it.name}" }
            Text(
                text = previewText,
                fontSize = 13.sp,
                color = Charcoal,
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = SurfaceBorder)
            Spacer(modifier = Modifier.height(10.dp))

            // Bottom Actions and Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Status Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(getStatusColor(order.status).copy(alpha = 0.15f))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = order.status,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = getStatusColor(order.status)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isUnseen) {
                        TextButton(
                            onClick = onMarkSeen,
                            modifier = Modifier.testTag("card_mark_seen_${order.orderId}")
                        ) {
                            Text("Mark Seen", fontSize = 12.sp, color = DeepGreen, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = onOpenDetails,
                        colors = ButtonDefaults.buttonColors(containerColor = DeepGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("card_manage_${order.orderId}")
                    ) {
                        Text("Manage", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminOrderDetailDialog(
    order: OrderEntity,
    revealPhone: Boolean,
    viewModel: ChiyaViewModel,
    onDismiss: () -> Unit,
    onStatusChange: (String) -> Unit,
    onPaymentStatusChange: (String) -> Unit,
    onDeleteOrder: () -> Unit
) {
    val items = viewModel.parseOrderItems(order.itemsSummaryJson)
    val sdf = SimpleDateFormat("hh:mm a • EEE, MMM dd", Locale.getDefault())
    val formattedTime = sdf.format(Date(order.timestamp))
    val displayPhone = if (revealPhone) order.customerPhone else SecurityUtils.maskPhoneNumber(order.customerPhone)

    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    val statusOptions = listOf(
        "New",
        "Accepted",
        "Preparing",
        "Ready",
        "Completed",
        "Cancelled"
    )

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Cancel & Delete Order?", fontWeight = FontWeight.Bold, color = Terracotta) },
            text = { Text("Are you sure you want to cancel order ${order.orderId}? This action removes it from the active kitchen board.") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmDialog = false
                        onDeleteOrder()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Terracotta)
                ) {
                    Text("Delete Order")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("Keep Order")
                }
            }
        )
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = WarmWhite),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Order Details",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            color = DeepGreen
                        )
                        Text(
                            text = formattedTime,
                            fontSize = 12.sp,
                            color = CharcoalMuted
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Customer Info
                Card(
                    colors = CardDefaults.cardColors(containerColor = Cream),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = "Customer: ${order.customerName}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Charcoal)
                        Text(text = "Phone: $displayPhone", fontSize = 13.sp, color = CharcoalMuted)
                        Text(
                            text = if (order.tableNumber != null) "Dine-in: Table #${order.tableNumber}" else "Takeaway: Pickup ${order.pickupTime ?: "Asap"}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = DeepGreen
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Order Items",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = Charcoal
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Item List
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Cream, RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                val variantInfo = when {
                                    item.variant != null -> " (${item.variant})"
                                    item.flavour != null -> " (${item.flavour})"
                                    else -> ""
                                }
                                Text(
                                    text = "${item.quantity}x ${item.name}$variantInfo",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Charcoal
                                )
                                Text(
                                    text = "@ NPR ${item.unitPrice.toInt()} each",
                                    fontSize = 11.sp,
                                    color = CharcoalMuted
                                )
                            }
                            Text(
                                text = "NPR ${item.totalPrice.toInt()}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = DeepGreen
                            )
                        }
                    }

                    HorizontalDivider(color = SurfaceBorder)

                    BillingAdminRow("Subtotal", order.subtotal)
                    if (order.discount > 0.0) BillingAdminRow("Discount", -order.discount)
                    BillingAdminRow("VAT", order.tax)
                    if (order.serviceCharge > 0.0) BillingAdminRow("Service charge", order.serviceCharge)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Total Payable", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Charcoal)
                        Text(
                            text = "NPR ${order.total.toInt()}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            fontFamily = FontFamily.Serif,
                            color = DeepGreen
                        )
                    }

                    Text(
                        text = "Payment: ${order.paymentMethod} • ${order.paymentStatus} • Receipt ${order.receiptNumber}",
                        fontSize = 11.sp,
                        color = CharcoalMuted
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Payment Status Section
                Text(
                    text = "Payment Status",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Charcoal
                )
                Spacer(modifier = Modifier.height(8.dp))

                val paymentOptions = listOf("Pending", "Paid", "Refunded", "Failed")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    paymentOptions.forEach { paymentStatus ->
                        val isCurrentPayment = order.paymentStatus.equals(paymentStatus, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isCurrentPayment) DeepGreen else Cream)
                                .clickable { onPaymentStatusChange(paymentStatus) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = paymentStatus,
                                fontSize = 11.sp,
                                fontWeight = if (isCurrentPayment) FontWeight.Bold else FontWeight.Normal,
                                color = if (isCurrentPayment) Color.White else Charcoal
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Update Status Section
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Kitchen & Dispatch Status",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Charcoal
                    )

                    IconButton(
                        onClick = { showDeleteConfirmDialog = true },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Cancel & Delete Order",
                            tint = Terracotta,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    statusOptions.forEach { status ->
                        val isCurrent = order.status == status
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isCurrent) DeepGreen else Cream)
                                .clickable { onStatusChange(status) }
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = status,
                                    fontSize = 13.sp,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isCurrent) Color.White else Charcoal
                                )
                                if (isCurrent) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fun getStatusColor(status: String): Color {
    return when {
        status.equals("New", ignoreCase = true) || status.contains("Placed", ignoreCase = true) -> Terracotta
        status.equals("Accepted", ignoreCase = true) -> DeepGreen
        status.equals("Preparing", ignoreCase = true) || status.contains("Kitchen", ignoreCase = true) -> WoodBrown
        status.equals("Ready", ignoreCase = true) -> DeepGreen
        status.equals("Completed", ignoreCase = true) || status.contains("Served", ignoreCase = true) -> DeepGreen
        status.equals("Cancelled", ignoreCase = true) -> Terracotta
        else -> Terracotta
    }
}
