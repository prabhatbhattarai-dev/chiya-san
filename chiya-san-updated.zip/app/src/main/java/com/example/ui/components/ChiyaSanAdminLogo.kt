package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.DinnerDining
import androidx.compose.material.icons.filled.LocalCafe
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.Cream
import com.example.ui.theme.DeepGreen
import com.example.ui.theme.TeaGreen
import com.example.ui.theme.Terracotta
import com.example.ui.theme.WoodBrown

/**
 * Custom Brand Logo for the Chiya San Admin & Kitchen Portal.
 * Combines traditional Nepali tea heritage with professional kitchen order dispatch visual elements.
 */
@Composable
fun ChiyaSanAdminLogo(
    modifier: Modifier = Modifier,
    size: Dp = 88.dp,
    showText: Boolean = false,
    subtitle: String = "Kitchen & Order Management"
) {
    if (showText) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = modifier
        ) {
            ChiyaSanAdminLogoEmblem(size = size)
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "Chiya San",
                fontSize = if (size > 60.dp) 26.sp else 20.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = DeepGreen
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = subtitle,
                fontSize = if (size > 60.dp) 13.sp else 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = WoodBrown,
                letterSpacing = 0.5.sp
            )
        }
    } else {
        ChiyaSanAdminLogoEmblem(
            size = size,
            modifier = modifier
        )
    }
}

/**
 * Compact Header Variant for Admin Dashboard Bar
 */
@Composable
fun ChiyaSanAdminHeaderBrand(
    modifier: Modifier = Modifier,
    subtitle: String = "Kitchen & Order Management"
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
    ) {
        ChiyaSanAdminLogoEmblem(size = 44.dp)
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = "Chiya San",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = Color.White
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = TeaGreen,
                letterSpacing = 0.3.sp
            )
        }
    }
}

@Composable
private fun ChiyaSanAdminLogoEmblem(
    size: Dp,
    modifier: Modifier = Modifier
) {
    val cornerRadius = size * 0.28f
    val borderWidth = (size.value * 0.035f).coerceAtLeast(1.5f).dp

    Box(
        modifier = modifier
            .size(size)
            .shadow(
                elevation = 6.dp,
                shape = RoundedCornerShape(cornerRadius),
                ambientColor = DeepGreen.copy(alpha = 0.3f),
                spotColor = DeepGreen.copy(alpha = 0.4f)
            )
            .clip(RoundedCornerShape(cornerRadius))
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        DeepGreen,
                        Color(0xFF142921)
                    )
                )
            )
            .border(
                width = borderWidth,
                brush = Brush.sweepGradient(
                    colors = listOf(
                        TeaGreen,
                        Color(0xFFE5D5B8),
                        TeaGreen
                    )
                ),
                shape = RoundedCornerShape(cornerRadius)
            ),
        contentAlignment = Alignment.Center
    ) {
        // Decorative steam & tea cup canvas
        Canvas(modifier = Modifier.size(size * 0.75f)) {
            val w = this.size.width
            val h = this.size.height

            // Steam curves rising above cup
            val steamPath1 = Path().apply {
                moveTo(w * 0.38f, h * 0.35f)
                cubicTo(
                    w * 0.32f, h * 0.26f,
                    w * 0.44f, h * 0.18f,
                    w * 0.38f, h * 0.08f
                )
            }
            val steamPath2 = Path().apply {
                moveTo(w * 0.52f, h * 0.34f)
                cubicTo(
                    w * 0.58f, h * 0.24f,
                    w * 0.46f, h * 0.16f,
                    w * 0.54f, h * 0.06f
                )
            }
            val steamPath3 = Path().apply {
                moveTo(w * 0.66f, h * 0.35f)
                cubicTo(
                    w * 0.60f, h * 0.27f,
                    w * 0.72f, h * 0.19f,
                    w * 0.66f, h * 0.10f
                )
            }

            val steamStroke = Stroke(
                width = (w * 0.045f).coerceAtLeast(1.8f),
                cap = StrokeCap.Round
            )

            drawPath(steamPath1, color = TeaGreen.copy(alpha = 0.85f), style = steamStroke)
            drawPath(steamPath2, color = Color(0xFFF2E6D0).copy(alpha = 0.95f), style = steamStroke)
            drawPath(steamPath3, color = TeaGreen.copy(alpha = 0.85f), style = steamStroke)

            // Saucer line
            drawLine(
                color = TeaGreen,
                start = Offset(w * 0.16f, h * 0.86f),
                end = Offset(w * 0.84f, h * 0.86f),
                strokeWidth = (w * 0.05f).coerceAtLeast(2f),
                cap = StrokeCap.Round
            )
        }

        // Central Tea Cup & Nepali Emblem
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(top = size * 0.18f)
        ) {
            Box(
                contentAlignment = Alignment.Center
            ) {
                // Cup silhouette icon
                Icon(
                    imageVector = Icons.Default.LocalCafe,
                    contentDescription = null,
                    tint = Cream,
                    modifier = Modifier.size(size * 0.44f)
                )

                // Devanagari seal "चिया" overlay inside cup
                if (size >= 48.dp) {
                    Text(
                        text = "चिया",
                        color = DeepGreen,
                        fontSize = (size.value * 0.13f).sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Serif,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        // Small subtle kitchen order bell / checklist badge in bottom right corner
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = size * 0.08f, end = size * 0.08f)
                .size(size * 0.32f)
                .clip(CircleShape)
                .background(Color(0xFFC2593F)) // Terracotta kitchen dispatch badge
                .border((size.value * 0.02f).coerceAtLeast(1f).dp, Cream, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.RestaurantMenu,
                contentDescription = null,
                tint = Cream,
                modifier = Modifier.size(size * 0.18f)
            )
        }
    }
}
