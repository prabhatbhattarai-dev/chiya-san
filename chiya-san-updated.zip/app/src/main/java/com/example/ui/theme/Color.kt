package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Cream = Color(0xFFF5F0E6)
val WarmWhite = Color(0xFFFBF9F3)
val Charcoal = Color(0xFF202421)
val TeaGreen = Color(0xFF5EAA8A)
val DeepGreen = Color(0xFF315F4D)
val WoodBrown = Color(0xFF6B4630)
val Terracotta = Color(0xFFB96D4A)

val CharcoalMuted = Color(0xFF636E67)
val SurfaceBorder = Color(0xFFE2DAD0)
val CardHighlight = Color(0xFFEFE9DC)

