package com.example.ui.theme

import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val ChiyaColorScheme = lightColorScheme(
    primary = DeepGreen,
    onPrimary = Color.White,
    primaryContainer = TeaGreen,
    onPrimaryContainer = Color.White,
    secondary = WoodBrown,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEADBCE),
    onSecondaryContainer = WoodBrown,
    tertiary = Terracotta,
    onTertiary = Color.White,
    background = Cream,
    onBackground = Charcoal,
    surface = WarmWhite,
    onSurface = Charcoal,
    surfaceVariant = CardHighlight,
    onSurfaceVariant = CharcoalMuted,
    outline = SurfaceBorder
)

@Composable
fun ChiyaSanTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ChiyaColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun chiyaTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Charcoal,
    unfocusedTextColor = Charcoal,
    disabledTextColor = Charcoal.copy(alpha = 0.4f),
    errorTextColor = Terracotta,
    focusedContainerColor = WarmWhite,
    unfocusedContainerColor = WarmWhite,
    disabledContainerColor = WarmWhite,
    cursorColor = DeepGreen,
    errorCursorColor = Terracotta,
    selectionColors = TextSelectionColors(
        handleColor = DeepGreen,
        backgroundColor = TeaGreen.copy(alpha = 0.35f)
    ),
    focusedBorderColor = DeepGreen,
    unfocusedBorderColor = SurfaceBorder,
    disabledBorderColor = SurfaceBorder.copy(alpha = 0.5f),
    errorBorderColor = Terracotta,
    focusedLeadingIconColor = DeepGreen,
    unfocusedLeadingIconColor = DeepGreen,
    disabledLeadingIconColor = CharcoalMuted.copy(alpha = 0.5f),
    errorLeadingIconColor = Terracotta,
    focusedTrailingIconColor = CharcoalMuted,
    unfocusedTrailingIconColor = CharcoalMuted,
    disabledTrailingIconColor = CharcoalMuted.copy(alpha = 0.5f),
    errorTrailingIconColor = Terracotta,
    focusedLabelColor = DeepGreen,
    unfocusedLabelColor = CharcoalMuted,
    disabledLabelColor = CharcoalMuted.copy(alpha = 0.5f),
    errorLabelColor = Terracotta,
    focusedPlaceholderColor = CharcoalMuted.copy(alpha = 0.65f),
    unfocusedPlaceholderColor = CharcoalMuted.copy(alpha = 0.65f),
    disabledPlaceholderColor = CharcoalMuted.copy(alpha = 0.4f),
    errorPlaceholderColor = CharcoalMuted.copy(alpha = 0.65f),
    focusedSupportingTextColor = CharcoalMuted,
    unfocusedSupportingTextColor = CharcoalMuted
)

val ChiyaInputTextStyle = TextStyle(
    color = Charcoal,
    fontSize = 15.sp,
    fontWeight = FontWeight.Normal
)
