package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CategoryFilterChips
import com.example.ui.components.HeaderBar
import com.example.ui.components.HookahFlavourDialog
import com.example.ui.components.MenuItemCard
import com.example.ui.components.MomoVariantDialog
import com.example.ui.components.PersistentCartBar
import com.example.ui.theme.Charcoal
import com.example.ui.theme.CharcoalMuted
import com.example.ui.theme.Cream
import com.example.ui.viewmodel.ChiyaViewModel

@Composable
fun MenuScreen(
    viewModel: ChiyaViewModel,
    onOpenCart: () -> Unit,
    modifier: Modifier = Modifier
) {
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val filteredItems by viewModel.filteredMenuItems.collectAsState()
    val activeMomo by viewModel.activeMomoItem.collectAsState()
    val activeHookah by viewModel.activeHookahItem.collectAsState()
    val cartCount by viewModel.cartTotalCount.collectAsState()
    val cartSubtotal by viewModel.cartSubtotal.collectAsState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Cream)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            HeaderBar(
                searchQuery = searchQuery,
                onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                cartCount = cartCount,
                onOpenCart = onOpenCart
            )

            CategoryFilterChips(
                categories = viewModel.menuRepository.categories,
                selectedCategory = selectedCategory,
                onCategorySelected = { viewModel.selectCategory(it) }
            )

            if (filteredItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "No tea or food found",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            color = Charcoal
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Try searching for something else or pick a different category.",
                            fontSize = 14.sp,
                            color = CharcoalMuted,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        end = 16.dp,
                        top = 8.dp,
                        bottom = if (cartCount > 0) 90.dp else 24.dp
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("menu_items_list")
                ) {
                    items(filteredItems, key = { it.id }) { item ->
                        MenuItemCard(
                            item = item,
                            onAddToCart = { viewModel.addToCartDirect(it) },
                            onOpenMomoSelector = { viewModel.openMomoSelector(it) },
                            onOpenHookahSelector = { viewModel.openHookahSelector(it) },
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Floating persistent cart bar
        PersistentCartBar(
            totalCount = cartCount,
            subtotal = cartSubtotal,
            onOpenCart = onOpenCart,
            modifier = Modifier.align(Alignment.BottomCenter)
        )

        // Momo variant popup
        activeMomo?.let { momo ->
            MomoVariantDialog(
                item = momo,
                onDismiss = { viewModel.dismissMomoSelector() },
                onAddToCart = { item, variant, price ->
                    viewModel.addMomoToCart(item, variant, price)
                }
            )
        }

        // Hookah flavour popup
        activeHookah?.let { hookah ->
            HookahFlavourDialog(
                item = hookah,
                onDismiss = { viewModel.dismissHookahSelector() },
                onAddToCart = { item, flavour, price ->
                    viewModel.addHookahToCart(item, flavour, price)
                }
            )
        }
    }
}
