package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ChiyaSanAdminLogo
import com.example.ui.theme.Charcoal
import com.example.ui.theme.CharcoalMuted
import com.example.ui.theme.ChiyaInputTextStyle
import com.example.ui.theme.Cream
import com.example.ui.theme.DeepGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.Terracotta
import com.example.ui.theme.WarmWhite
import com.example.ui.theme.chiyaTextFieldColors
import com.example.ui.viewmodel.ChiyaViewModel
import kotlinx.coroutines.delay

enum class AdminAuthStep {
    ENTER_PHONE,
    ENTER_OTP
}

@Composable
fun AdminLoginScreen(
    viewModel: ChiyaViewModel,
    onLoginSuccess: () -> Unit,
    onBackToCustomerView: () -> Unit,
    modifier: Modifier = Modifier
) {
    var authStep by remember { mutableStateOf(AdminAuthStep.ENTER_PHONE) }
    var countryCode by remember { mutableStateOf("+977") }
    var phoneNumber by remember { mutableStateOf("") }
    var otpCode by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var isStatusSuccess by remember { mutableStateOf(false) }
    var resendCountdown by remember { mutableIntStateOf(0) }

    val focusManager = LocalFocusManager.current
    val isLoading by viewModel.isAdminAuthLoading.collectAsState()
    val authError by viewModel.adminAuthError.collectAsState()
    val isAuthenticated by viewModel.isAdminLoggedIn.collectAsState()

    // Resend countdown timer ticker
    LaunchedEffect(resendCountdown) {
        if (resendCountdown > 0) {
            delay(1000L)
            resendCountdown -= 1
        }
    }

    // Direct transition on successful authentication
    if (isAuthenticated) {
        LaunchedEffect(Unit) {
            onLoginSuccess()
        }
    }

    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Cream)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Top Navigation Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackToCustomerView,
                    modifier = Modifier.testTag("admin_login_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Menu",
                        tint = DeepGreen
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(DeepGreen.copy(alpha = 0.08f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (authStep == AdminAuthStep.ENTER_PHONE) "/admin/phone-auth" else "/admin/verify-otp",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DeepGreen
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Chiya San Admin Logo & Brand Identity
            ChiyaSanAdminLogo(
                size = 88.dp,
                showText = true,
                subtitle = "Kitchen & Order Management"
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Phone OTP Login Card Container
            Card(
                colors = CardDefaults.cardColors(containerColor = WarmWhite),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(SurfaceBorder)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_login_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header Badge
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(DeepGreen.copy(alpha = 0.08f))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = if (authStep == AdminAuthStep.ENTER_PHONE) Icons.Default.Phone else Icons.Default.Sms,
                            contentDescription = null,
                            tint = DeepGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (authStep == AdminAuthStep.ENTER_PHONE) "SMS OTP Authentication" else "Verify SMS Code",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = DeepGreen
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = if (authStep == AdminAuthStep.ENTER_PHONE) "Admin Portal Sign In" else "Enter Verification Code",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = DeepGreen,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = if (authStep == AdminAuthStep.ENTER_PHONE)
                            "Enter your authorized mobile number to receive a secure one-time verification code via SMS."
                        else
                            "A 6-digit code has been dispatched to $countryCode $phoneNumber. Enter the code below to log in.",
                        fontSize = 12.sp,
                        color = CharcoalMuted,
                        textAlign = TextAlign.Center,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // STEP 1: Phone Number Input
                    if (authStep == AdminAuthStep.ENTER_PHONE) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Country Code Badge
                            Box(
                                modifier = Modifier
                                    .height(56.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .border(1.dp, SurfaceBorder, RoundedCornerShape(14.dp))
                                    .background(Cream)
                                    .padding(horizontal = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "🇳🇵",
                                        fontSize = 16.sp
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = countryCode,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DeepGreen
                                    )
                                }
                            }

                            // Mobile Number Field
                            OutlinedTextField(
                                value = phoneNumber,
                                onValueChange = { input ->
                                    val digitsOnly = input.filter { it.isDigit() }
                                    if (digitsOnly.length <= 10) {
                                        phoneNumber = digitsOnly
                                    }
                                    statusMessage = null
                                    if (authError != null) viewModel.clearAdminAuthError()
                                },
                                label = { Text("Admin Mobile") },
                                placeholder = { Text("98XXXXXXXX") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Phone,
                                        contentDescription = null,
                                        tint = DeepGreen
                                    )
                                },
                                singleLine = true,
                                textStyle = ChiyaInputTextStyle,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Phone,
                                    imeAction = ImeAction.Done
                                ),
                                keyboardActions = KeyboardActions(
                                    onDone = {
                                        focusManager.clearFocus()
                                        if (phoneNumber.length >= 10) {
                                            viewModel.sendAdminPhoneOtp("$countryCode$phoneNumber") { result ->
                                                result.onSuccess { msg ->
                                                    authStep = AdminAuthStep.ENTER_OTP
                                                    statusMessage = msg
                                                    isStatusSuccess = true
                                                    resendCountdown = 60
                                                }.onFailure { err ->
                                                    statusMessage = err.message ?: "Failed to send verification SMS."
                                                    isStatusSuccess = false
                                                }
                                            }
                                        } else {
                                            statusMessage = "Please enter a valid 10-digit mobile number."
                                            isStatusSuccess = false
                                        }
                                    }
                                ),
                                colors = chiyaTextFieldColors(),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("admin_login_phone_input")
                            )
                        }
                    }

                    // STEP 2: 6-Digit OTP Verification Code Input
                    if (authStep == AdminAuthStep.ENTER_OTP) {
                        OutlinedTextField(
                            value = otpCode,
                            onValueChange = { input ->
                                val digits = input.filter { it.isDigit() }
                                if (digits.length <= 6) {
                                    otpCode = digits
                                }
                                statusMessage = null
                                if (authError != null) viewModel.clearAdminAuthError()
                            },
                            label = { Text("6-Digit OTP Code") },
                            placeholder = { Text("• • • • • •") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = DeepGreen
                                )
                            },
                            singleLine = true,
                            textStyle = ChiyaInputTextStyle.copy(
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                letterSpacing = 6.sp
                            ),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.NumberPassword,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    focusManager.clearFocus()
                                    if (otpCode.length == 6) {
                                        viewModel.verifyAdminPhoneOtp(
                                            phoneNumber = "$countryCode$phoneNumber",
                                            otpCode = otpCode,
                                            onSuccess = { onLoginSuccess() },
                                            onResult = { res ->
                                                res.onFailure { err ->
                                                    statusMessage = err.message ?: "Invalid verification code."
                                                    isStatusSuccess = false
                                                }
                                            }
                                        )
                                    }
                                }
                            ),
                            colors = chiyaTextFieldColors(),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_otp_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Resend & Change Phone Number Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(
                                onClick = {
                                    authStep = AdminAuthStep.ENTER_PHONE
                                    otpCode = ""
                                    statusMessage = null
                                    viewModel.clearAdminAuthError()
                                },
                                modifier = Modifier.testTag("admin_change_phone_button")
                            ) {
                                Text(
                                    text = "Change Number",
                                    fontSize = 12.sp,
                                    color = CharcoalMuted
                                )
                            }

                            TextButton(
                                onClick = {
                                    if (resendCountdown == 0) {
                                        viewModel.sendAdminPhoneOtp("$countryCode$phoneNumber") { res ->
                                            res.onSuccess { msg ->
                                                statusMessage = msg
                                                isStatusSuccess = true
                                                resendCountdown = 60
                                            }.onFailure { err ->
                                                statusMessage = err.message ?: "Failed to resend code."
                                                isStatusSuccess = false
                                            }
                                        }
                                    }
                                },
                                enabled = resendCountdown == 0 && !isLoading,
                                modifier = Modifier.testTag("admin_resend_otp_button")
                            ) {
                                Text(
                                    text = if (resendCountdown > 0) "Resend SMS (${resendCountdown}s)" else "Resend Code",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (resendCountdown == 0) DeepGreen else CharcoalMuted
                                )
                            }
                        }
                    }

                    // Active Error / Success Feedback Banner
                    val activeError = authError ?: if (statusMessage != null && !isStatusSuccess) statusMessage else null
                    if (activeError != null) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Terracotta.copy(alpha = 0.1f)),
                            shape = RoundedCornerShape(12.dp),
                            border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(Terracotta)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = Terracotta,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = activeError,
                                    color = Terracotta,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.testTag("admin_login_error_text")
                                )
                            }
                        }
                    } else if (statusMessage != null && isStatusSuccess) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DeepGreen.copy(alpha = 0.1f)),
                            shape = RoundedCornerShape(12.dp),
                            border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(DeepGreen)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = DeepGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = statusMessage ?: "",
                                    color = DeepGreen,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Primary Action Button (Send Code vs Verify Code)
                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            statusMessage = null
                            if (authStep == AdminAuthStep.ENTER_PHONE) {
                                if (phoneNumber.length < 10) {
                                    statusMessage = "Please enter a valid 10-digit mobile number."
                                    isStatusSuccess = false
                                    return@Button
                                }
                                viewModel.sendAdminPhoneOtp("$countryCode$phoneNumber") { res ->
                                    res.onSuccess { msg ->
                                        authStep = AdminAuthStep.ENTER_OTP
                                        statusMessage = msg
                                        isStatusSuccess = true
                                        resendCountdown = 60
                                    }.onFailure { err ->
                                        statusMessage = err.message ?: "Failed to dispatch verification SMS."
                                        isStatusSuccess = false
                                    }
                                }
                            } else {
                                if (otpCode.length < 6) {
                                    statusMessage = "Please enter the complete 6-digit verification code."
                                    isStatusSuccess = false
                                    return@Button
                                }
                                viewModel.verifyAdminPhoneOtp(
                                    phoneNumber = "$countryCode$phoneNumber",
                                    otpCode = otpCode,
                                    onSuccess = { onLoginSuccess() },
                                    onResult = { res ->
                                        res.onFailure { err ->
                                            statusMessage = err.message ?: "Verification failed. Please check the code."
                                            isStatusSuccess = false
                                        }
                                    }
                                )
                            }
                        },
                        enabled = !isLoading && (if (authStep == AdminAuthStep.ENTER_PHONE) phoneNumber.isNotBlank() else otpCode.length == 6),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = DeepGreen,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag(if (authStep == AdminAuthStep.ENTER_PHONE) "admin_send_otp_button" else "admin_verify_otp_button")
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (authStep == AdminAuthStep.ENTER_PHONE) "Sending SMS Code..." else "Verifying Code...",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            Text(
                                text = if (authStep == AdminAuthStep.ENTER_PHONE) "Send Verification Code" else "Verify & Access Kitchen",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Push Notification & Real-Time Orders Feature Info Banner
            Card(
                colors = CardDefaults.cardColors(containerColor = WarmWhite),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(SurfaceBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(DeepGreen.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = DeepGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Instant Order Push Notifications",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Charcoal
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Admin device receives live heads-up push alerts with order items, table number & total when new orders arrive.",
                            fontSize = 11.sp,
                            color = CharcoalMuted,
                            lineHeight = 15.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Secure Admin Notice
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = DeepGreen,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Supabase Phone Auth • +977 Nepal Mobile Network",
                    fontSize = 11.sp,
                    color = DeepGreen,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
