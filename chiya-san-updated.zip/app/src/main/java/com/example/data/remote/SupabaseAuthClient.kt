package com.example.data.remote

import android.util.Log
import com.example.util.SecurityUtils
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

class SupabaseAuthClient(
    customUrl: String? = null,
    customAnonKey: String? = null
) {
    init {
        if (!customUrl.isNullOrBlank() || !customAnonKey.isNullOrBlank()) {
            SupabaseClientConfig.setCustomCredentials(customUrl, customAnonKey)
        }
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val authResponseAdapter = moshi.adapter(SupabaseAuthResponse::class.java)
    private val authErrorAdapter = moshi.adapter(SupabaseAuthError::class.java)
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    fun updateConfig(url: String, anonKey: String) {
        SupabaseClientConfig.setCustomCredentials(url, anonKey)
    }

    fun getSupabaseUrl(): String = SupabaseClientConfig.getSupabaseUrl()
    fun getSupabaseAnonKey(): String = SupabaseClientConfig.getSupabaseAnonKey()

    fun isConfigured(): Boolean = SupabaseClientConfig.isConfigured()

    /**
     * Send Phone OTP verification code via Supabase GoTrue Auth SMS
     */
    suspend fun sendPhoneOtp(phoneNumber: String): Result<String> = withContext(Dispatchers.IO) {
        val supabaseUrl = getSupabaseUrl()
        val supabaseAnonKey = getSupabaseAnonKey()

        if (!isConfigured()) {
            return@withContext Result.failure(
                Exception("Supabase credentials are not configured. Please verify your Supabase URL and Publishable Key.")
            )
        }

        try {
            val endpoint = "$supabaseUrl/auth/v1/otp"
            val payload = JSONObject().apply {
                put("phone", phoneNumber.trim())
                put("create_user", true)
                put("channel", "sms")
            }.toString()

            val request = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", "Bearer $supabaseAnonKey")
                .addHeader("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (response.isSuccessful || response.code in 200..204) {
                Log.d("SupabaseAuthClient", "OTP SMS dispatched successfully to $phoneNumber")
                Result.success("Verification code sent to $phoneNumber. Please check your SMS inbox.")
            } else {
                val errorMsg = try {
                    val errorObj = authErrorAdapter.fromJson(responseBody)
                    val rawMsg = errorObj?.formattedMessage ?: ""
                    when {
                        rawMsg.contains("sms provider", ignoreCase = true) || rawMsg.contains("provider not found", ignoreCase = true) ->
                            "SMS Provider Configuration Required: Supabase Phone Auth is active, but an SMS gateway (Twilio / MessageBird / Vonage) needs to be configured in your Supabase Auth Settings."
                        rawMsg.contains("rate limit", ignoreCase = true) || rawMsg.contains("too many requests", ignoreCase = true) || response.code == 429 ->
                            "SMS rate limit reached. Please wait a minute before requesting a new code."
                        rawMsg.contains("invalid phone", ignoreCase = true) || rawMsg.contains("phone number", ignoreCase = true) ->
                            "Invalid phone number format. Please ensure you entered a valid 10-digit mobile number."
                        rawMsg.contains("signups not allowed", ignoreCase = true) ->
                            "This phone number is not registered as an authorized Admin. Please add this number in Supabase Authentication or enable phone signups."
                        response.code == 422 -> "Unable to send SMS to this phone number. Please verify the number format."
                        else -> errorObj?.formattedMessage ?: "Failed to dispatch verification SMS (HTTP ${response.code})."
                    }
                } catch (e: Exception) {
                    "Failed to dispatch verification SMS. Please check your connection."
                }
                Result.failure(Exception(errorMsg))
            }
        } catch (e: UnknownHostException) {
            Log.e("SupabaseAuthClient", "DNS resolution failed: ${e.message}")
            Result.failure(Exception("Unable to resolve Supabase server address. Please verify your internet connection."))
        } catch (e: SocketTimeoutException) {
            Result.failure(Exception("Connection timed out. Please check your internet connection."))
        } catch (e: Exception) {
            Log.e("SupabaseAuthClient", "Phone OTP send error", e)
            Result.failure(Exception("Failed to send verification SMS: ${e.message}"))
        }
    }

    /**
     * Verify Phone OTP code with Supabase GoTrue Auth
     */
    suspend fun verifyPhoneOtp(phoneNumber: String, token: String): Result<SupabaseAuthResponse> = withContext(Dispatchers.IO) {
        val supabaseUrl = getSupabaseUrl()
        val supabaseAnonKey = getSupabaseAnonKey()

        if (!isConfigured()) {
            return@withContext Result.failure(
                Exception("Supabase credentials are not configured.")
            )
        }

        try {
            val endpoint = "$supabaseUrl/auth/v1/verify"
            val payload = JSONObject().apply {
                put("type", "sms")
                put("phone", phoneNumber.trim())
                put("token", token.trim())
            }.toString()

            val request = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", "Bearer $supabaseAnonKey")
                .addHeader("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val authResponse = authResponseAdapter.fromJson(responseBody)
                if (authResponse != null && (authResponse.accessToken.isNotBlank() || authResponse.user != null)) {
                    Result.success(authResponse)
                } else {
                    // Manual json parse fallback
                    val obj = JSONObject(responseBody)
                    val userObj = obj.optJSONObject("user")
                    val user = if (userObj != null) {
                        SupabaseUser(
                            id = userObj.optString("id", SecurityUtils.generateSecureTrackingToken()),
                            phone = userObj.optString("phone", phoneNumber),
                            role = userObj.optString("role", "authenticated")
                        )
                    } else {
                        SupabaseUser(id = SecurityUtils.generateSecureTrackingToken(), phone = phoneNumber, role = "authenticated")
                    }
                    Result.success(SupabaseAuthResponse(accessToken = obj.optString("access_token", ""), user = user))
                }
            } else {
                val errorMsg = try {
                    val errorObj = authErrorAdapter.fromJson(responseBody)
                    val raw = errorObj?.formattedMessage ?: ""
                    when {
                        raw.contains("expired", ignoreCase = true) || raw.contains("otp expired", ignoreCase = true) ->
                            "The verification code has expired. Please request a new code."
                        raw.contains("invalid", ignoreCase = true) || raw.contains("wrong", ignoreCase = true) || response.code in 400..422 ->
                            "Invalid verification code. Please check the 6-digit code in your SMS and try again."
                        else -> errorObj?.formattedMessage ?: "Verification failed. Please check the code."
                    }
                } catch (e: Exception) {
                    "Invalid or expired verification code."
                }
                Result.failure(Exception(errorMsg))
            }
        } catch (e: UnknownHostException) {
            Result.failure(Exception("Unable to resolve Supabase server address. Please verify your internet connection."))
        } catch (e: Exception) {
            Log.e("SupabaseAuthClient", "Phone OTP verify error", e)
            Result.failure(Exception("Verification failed: ${e.message}"))
        }
    }

    /**
     * Register Admin Device Token for Push Notifications in Supabase 'admin_devices'
     */
    suspend fun registerAdminDeviceToken(
        adminToken: String?,
        adminId: String,
        phone: String,
        fcmToken: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (!isConfigured() || fcmToken.isBlank()) {
            return@withContext Result.success(Unit)
        }

        try {
            val supabaseUrl = getSupabaseUrl()
            val supabaseAnonKey = getSupabaseAnonKey()
            val endpoint = "$supabaseUrl/rest/v1/admin_devices"

            val authBearer = if (!adminToken.isNullOrBlank()) adminToken else supabaseAnonKey
            val payload = JSONObject().apply {
                put("admin_id", adminId)
                put("phone", phone)
                put("device_token", fcmToken)
                put("platform", "android")
                put("updated_at", System.currentTimeMillis())
            }.toString()

            val request = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", "Bearer $authBearer")
                .addHeader("Content-Type", "application/json")
                .addHeader("Prefer", "resolution=merge-duplicates")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful || response.code in 200..204) {
                Log.d("SupabaseAuthClient", "Admin device push token registered with Supabase successfully.")
                Result.success(Unit)
            } else {
                Log.w("SupabaseAuthClient", "Admin device token registration returned HTTP ${response.code}")
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Log.w("SupabaseAuthClient", "Device token registration skipped: ${e.message}")
            Result.success(Unit)
        }
    }

    /**
     * Authenticate via Supabase GoTrue Auth with Email and Password
     */
    suspend fun signInWithPassword(email: String, password: String): Result<SupabaseAuthResponse> = withContext(Dispatchers.IO) {
        val supabaseUrl = getSupabaseUrl()
        val supabaseAnonKey = getSupabaseAnonKey()

        if (!isConfigured()) {
            return@withContext Result.failure(
                Exception("Supabase credentials are not configured. Please configure your Supabase Project URL and Publishable Key.")
            )
        }

        try {
            val endpoint = "$supabaseUrl/auth/v1/token?grant_type=password"
            val payload = JSONObject().apply {
                put("email", email.trim())
                put("password", password)
            }.toString()

            val request = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", "Bearer $supabaseAnonKey")
                .addHeader("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val authResponse = authResponseAdapter.fromJson(responseBody)
                if (authResponse != null && authResponse.accessToken.isNotBlank()) {
                    Result.success(authResponse)
                } else {
                    Result.failure(Exception("Authentication server returned an unexpected response."))
                }
            } else {
                val errorMsg = try {
                    val errorObj = authErrorAdapter.fromJson(responseBody)
                    when {
                        errorObj?.errorDescription?.contains("invalid login", ignoreCase = true) == true -> "Invalid admin email or password."
                        errorObj?.message?.contains("invalid login", ignoreCase = true) == true -> "Invalid admin email or password."
                        errorObj?.errorDescription?.contains("email not confirmed", ignoreCase = true) == true -> "Please confirm your email address in Supabase or disable email confirmation in Auth settings."
                        response.code == 400 -> "Invalid admin email or password."
                        response.code in 401..403 -> "Invalid email or unauthorized admin access."
                        else -> errorObj?.formattedMessage ?: "Authentication failed (HTTP ${response.code})."
                    }
                } catch (e: Exception) {
                    "Invalid admin email or password."
                }
                Result.failure(Exception(errorMsg))
            }
        } catch (e: UnknownHostException) {
            Log.e("SupabaseAuthClient", "Network DNS failure: ${e.message}")
            Result.failure(Exception("Unable to resolve Supabase server address. Please verify your internet connection."))
        } catch (e: SocketTimeoutException) {
            Log.e("SupabaseAuthClient", "Connection timeout: ${e.message}")
            Result.failure(Exception("Connection timed out. Please check your internet connection and try again."))
        } catch (e: ConnectException) {
            Log.e("SupabaseAuthClient", "Connection refused: ${e.message}")
            Result.failure(Exception("Unable to reach Supabase backend server."))
        } catch (e: IOException) {
            Log.e("SupabaseAuthClient", "Network IO error: ${e.message}")
            Result.failure(Exception("Network error while connecting to Supabase: ${e.message}"))
        } catch (e: Exception) {
            Log.e("SupabaseAuthClient", "Unexpected sign in error", e)
            Result.failure(Exception("Authentication error: ${e.message}"))
        }
    }

    /**
     * Send Password Reset Email via Supabase Auth
     */
    suspend fun sendPasswordResetEmail(email: String): Result<String> = withContext(Dispatchers.IO) {
        val supabaseUrl = getSupabaseUrl()
        val supabaseAnonKey = getSupabaseAnonKey()

        if (!isConfigured()) {
            return@withContext Result.failure(
                Exception("Supabase credentials are not configured.")
            )
        }

        try {
            val endpoint = "$supabaseUrl/auth/v1/recover"
            val payload = JSONObject().apply {
                put("email", email.trim())
            }.toString()

            val request = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", "Bearer $supabaseAnonKey")
                .addHeader("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                Result.success("Password reset instructions have been dispatched to your authorized email address.")
            } else {
                val errorBody = response.body?.string() ?: ""
                val msg = try {
                    authErrorAdapter.fromJson(errorBody)?.formattedMessage ?: "Unable to send reset instructions."
                } catch (e: Exception) {
                    "Unable to send reset instructions. Please verify your email address."
                }
                Result.failure(Exception(msg))
            }
        } catch (e: Exception) {
            Log.e("SupabaseAuthClient", "Reset error", e)
            Result.failure(Exception("Unable to connect to Supabase: ${e.message}"))
        }
    }

    /**
     * Sign out session on Supabase
     */
    suspend fun signOut(accessToken: String): Result<Unit> = withContext(Dispatchers.IO) {
        val supabaseUrl = getSupabaseUrl()
        val supabaseAnonKey = getSupabaseAnonKey()

        if (!isConfigured()) {
            return@withContext Result.success(Unit)
        }

        try {
            val endpoint = "$supabaseUrl/auth/v1/logout"
            val request = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .post("{}".toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.success(Unit) // Local session cleared
        }
    }

    /**
     * Sign up / Register a new Admin account in Supabase Auth
     */
    suspend fun signUpAdmin(email: String, password: String): Result<SupabaseAuthResponse> = withContext(Dispatchers.IO) {
        val supabaseUrl = getSupabaseUrl()
        val supabaseAnonKey = getSupabaseAnonKey()

        if (!isConfigured()) {
            return@withContext Result.failure(
                Exception("Supabase credentials are not configured. Please configure your Supabase Project URL and Publishable Key.")
            )
        }

        try {
            val endpoint = "$supabaseUrl/auth/v1/signup"
            val metadata = JSONObject().apply {
                put("role", "admin")
                put("is_admin", true)
            }
            val payload = JSONObject().apply {
                put("email", email.trim())
                put("password", password)
                put("data", metadata)
            }.toString()

            val request = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", "Bearer $supabaseAnonKey")
                .addHeader("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val authResponse = try {
                    authResponseAdapter.fromJson(responseBody)
                } catch (e: Exception) {
                    null
                }

                if (authResponse != null) {
                    Result.success(authResponse)
                } else {
                    // In case email confirmation is required, Supabase returns user json without access token
                    val userObj = JSONObject(responseBody)
                    val createdUser = SupabaseUser(
                        id = userObj.optString("id", SecurityUtils.generateSecureTrackingToken()),
                        email = userObj.optString("email", email),
                        role = "admin"
                    )
                    Result.success(SupabaseAuthResponse(accessToken = "", tokenType = "bearer", user = createdUser))
                }
            } else {
                val errorMsg = try {
                    val errorObj = authErrorAdapter.fromJson(responseBody)
                    when {
                        errorObj?.message?.contains("already registered", ignoreCase = true) == true ->
                            "An account with this email already exists. Please sign in instead."
                        errorObj?.errorDescription?.contains("already registered", ignoreCase = true) == true ->
                            "An account with this email already exists. Please sign in instead."
                        errorObj?.message?.contains("password", ignoreCase = true) == true ->
                            errorObj.message
                        else -> errorObj?.formattedMessage ?: "Failed to create admin account (HTTP ${response.code})."
                    }
                } catch (e: Exception) {
                    "Failed to create admin account. Please check your credentials."
                }
                Result.failure(Exception(errorMsg))
            }
        } catch (e: UnknownHostException) {
            Log.e("SupabaseAuthClient", "Network DNS failure: ${e.message}")
            Result.failure(Exception("Unable to resolve Supabase server address. Please verify your internet connection."))
        } catch (e: SocketTimeoutException) {
            Log.e("SupabaseAuthClient", "Connection timeout: ${e.message}")
            Result.failure(Exception("Connection timed out. Please check your internet connection and try again."))
        } catch (e: ConnectException) {
            Log.e("SupabaseAuthClient", "Connection refused: ${e.message}")
            Result.failure(Exception("Unable to reach Supabase backend server."))
        } catch (e: IOException) {
            Log.e("SupabaseAuthClient", "Network IO error: ${e.message}")
            Result.failure(Exception("Network error while connecting to Supabase: ${e.message}"))
        } catch (e: Exception) {
            Log.e("SupabaseAuthClient", "Sign up error", e)
            Result.failure(Exception("Admin registration error: ${e.message}"))
        }
    }
}

