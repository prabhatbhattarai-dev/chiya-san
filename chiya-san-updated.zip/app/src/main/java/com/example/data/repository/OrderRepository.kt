package com.example.data.repository

import android.util.Log
import com.example.data.local.OrderDao
import com.example.data.local.OrderEntity
import com.example.data.model.CartItem
import com.example.data.model.BillingConfig
import com.example.data.model.OrderItemSummary
import com.example.data.remote.SupabaseOrderService
import com.example.util.SecurityUtils
import com.example.util.SlidingWindowRateLimiter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow
import kotlin.random.Random

data class OrderPlacementResult(
    val orderId: String,
    val trackingToken: String,
    val verifiedSubtotal: Double,
    val total: Double
)

class OrderRepository(
    private val orderDao: OrderDao,
    private val cartRepository: CartRepository,
    private val menuRepository: MenuRepository = MenuRepository(),
    private val supabaseOrderService: SupabaseOrderService = SupabaseOrderService(),
    private val firestoreOrderService: com.example.data.remote.FirestoreOrderService = com.example.data.remote.FirestoreOrderService()
) {

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val listType = Types.newParameterizedType(List::class.java, OrderItemSummary::class.java)
    private val jsonAdapter = moshi.adapter<List<OrderItemSummary>>(listType)

    // Rate limiter: Max 3 orders per 60 seconds per client
    private val orderRateLimiter = SlidingWindowRateLimiter(maxRequests = 3, windowDurationMs = 60_000L)

    val allOrders: Flow<List<OrderEntity>> = orderDao.getAllOrders()
    
    fun getSupabaseOrdersFlow(adminTokenProvider: () -> String? = { null }): Flow<List<OrderEntity>> {
        return supabaseOrderService.getRealTimeOrdersFlow(adminTokenProvider)
    }

    val firestoreOrdersFlow: Flow<List<OrderEntity>> = firestoreOrderService.getRealTimeOrdersFlow()

    suspend fun syncOrdersFromCloud(cloudOrders: List<OrderEntity>) {
        for (order in cloudOrders) {
            orderDao.insertOrder(order)
        }
    }

    suspend fun fetchOrdersFromSupabase(adminToken: String? = null): List<OrderEntity> {
        val result = supabaseOrderService.fetchOrdersFromSupabase(adminToken)
        val orders = result.getOrDefault(emptyList())
        if (orders.isNotEmpty()) {
            syncOrdersFromCloud(orders)
        }
        return orders
    }

    fun getCustomerOrders(orderIds: List<String>): Flow<List<OrderEntity>> {
        return orderDao.getOrdersByIds(orderIds)
    }

    suspend fun getOrderSecurely(orderId: String, trackingToken: String): OrderEntity? {
        val sanitizedId = SecurityUtils.sanitizeInput(orderId)
        val sanitizedToken = SecurityUtils.sanitizeInput(trackingToken)
        if (sanitizedId.isBlank() || sanitizedToken.isBlank()) return null
        return orderDao.getOrderByIdAndToken(sanitizedId, sanitizedToken)
    }

    /**
     * Authoritative, secure order placement:
     * 1. Rate-limiting check to prevent denial-of-service or fake order spam.
     * 2. Comprehensive input validation & sanitization (name, phone, table/time).
     * 3. Server-side/authoritative catalog price verification (prevents client price tampering).
     * 4. Cryptographically strong tracking token generation (prevents order enumeration IDOR).
     * 5. Real-time sync to Supabase database (orders and order_items tables).
     */
    suspend fun placeOrder(
        customerName: String,
        customerPhone: String,
        orderType: String,
        tableNumber: String?,
        pickupTime: String?,
        cartItems: List<CartItem>,
        clientSubtotal: Double
    ): Result<OrderPlacementResult> {
        // 1. Rate limiting check
        if (!orderRateLimiter.canProceed()) {
            val cooldown = orderRateLimiter.remainingCooldownSeconds()
            return Result.failure(
                IllegalStateException("Too many order requests. Please wait $cooldown seconds before ordering again.")
            )
        }

        // 2. Input validation & sanitization
        val nameValidation = SecurityUtils.validateCustomerName(customerName)
        if (!nameValidation.isValid) {
            val msg = (nameValidation as com.example.util.ValidationResult.Invalid).errorMessage
            return Result.failure(IllegalArgumentException(msg))
        }

        val phoneValidation = SecurityUtils.validatePhoneNumber(customerPhone)
        if (!phoneValidation.isValid) {
            val msg = (phoneValidation as com.example.util.ValidationResult.Invalid).errorMessage
            return Result.failure(IllegalArgumentException(msg))
        }

        val sanitizedName = SecurityUtils.sanitizeInput(customerName)
        val sanitizedPhone = SecurityUtils.sanitizeInput(customerPhone)
        var sanitizedTable: String? = null
        var sanitizedPickupTime: String? = null

        if (orderType.equals("Dine-in", ignoreCase = true)) {
            val tableValidation = SecurityUtils.validateTableNumber(tableNumber)
            if (!tableValidation.isValid) {
                val msg = (tableValidation as com.example.util.ValidationResult.Invalid).errorMessage
                return Result.failure(IllegalArgumentException(msg))
            }
            sanitizedTable = SecurityUtils.sanitizeInput(tableNumber)
        } else {
            val pickupValidation = SecurityUtils.validatePickupTime(pickupTime)
            if (!pickupValidation.isValid) {
                val msg = (pickupValidation as com.example.util.ValidationResult.Invalid).errorMessage
                return Result.failure(IllegalArgumentException(msg))
            }
            sanitizedPickupTime = SecurityUtils.sanitizeInput(pickupTime)
        }

        if (cartItems.isEmpty()) {
            return Result.failure(IllegalArgumentException("Cart cannot be empty when placing an order."))
        }

        // 3. Authoritative Canonical Price & Item Verification (Prevents Price Tampering)
        val verifiedSummaryItems = mutableListOf<OrderItemSummary>()
        var authoritativeSubtotal = 0.0

        for (cartItem in cartItems) {
            // Find canonical menu item by ID or name
            val menuItem = menuRepository.menuItems.find {
                it.id == cartItem.menuItemId || it.name.equals(cartItem.name, ignoreCase = true)
            } ?: return Result.failure(IllegalArgumentException("Unknown menu item: ${cartItem.name}"))

            // Verify quantity
            if (cartItem.quantity !in 1..50) {
                return Result.failure(IllegalArgumentException("Invalid quantity (${cartItem.quantity}) for ${cartItem.name}."))
            }

            // Determine canonical unit price
            val authoritativeUnitPrice: Double = if (menuItem.hasVariants && cartItem.selectedVariant != null) {
                val variant = menuItem.variants?.find { it.name.equals(cartItem.selectedVariant, ignoreCase = true) }
                    ?: return Result.failure(IllegalArgumentException("Invalid variant '${cartItem.selectedVariant}' for ${cartItem.name}."))
                variant.price
            } else {
                menuItem.price
            }

            if (menuItem.hasFlavours && cartItem.selectedFlavour != null) {
                if (menuItem.flavours?.contains(cartItem.selectedFlavour) != true) {
                    return Result.failure(IllegalArgumentException("Invalid flavour '${cartItem.selectedFlavour}' for ${cartItem.name}."))
                }
            }

            val itemTotal = authoritativeUnitPrice * cartItem.quantity
            authoritativeSubtotal += itemTotal

            verifiedSummaryItems.add(
                OrderItemSummary(
                    name = menuItem.name,
                    variant = cartItem.selectedVariant,
                    flavour = cartItem.selectedFlavour,
                    unitPrice = authoritativeUnitPrice,
                    quantity = cartItem.quantity
                )
            )
        }

        if (authoritativeSubtotal <= 0.0) {
            return Result.failure(IllegalArgumentException("Invalid calculated order total."))
        }

        // 4. Generate random order ID & cryptographically unpredictable tracking token
        val randomNum = Random.nextInt(1000, 9999)
        val orderId = "CS-$randomNum"
        val trackingToken = SecurityUtils.generateSecureTrackingToken()

        val jsonString = jsonAdapter.toJson(verifiedSummaryItems)

        // Billing: authoritative server-side-style calculation from verified menu prices.
        val discount = BillingConfig.DEFAULT_DISCOUNT.coerceIn(0.0, authoritativeSubtotal)
        val taxableAmount = (authoritativeSubtotal - discount).coerceAtLeast(0.0)
        val tax = taxableAmount * BillingConfig.VAT_RATE
        val serviceCharge = taxableAmount * BillingConfig.SERVICE_CHARGE_RATE
        val grandTotal = taxableAmount + tax + serviceCharge

        val orderEntity = OrderEntity(
            orderId = orderId,
            customerName = sanitizedName,
            customerPhone = sanitizedPhone,
            orderType = if (orderType.equals("Dine-in", ignoreCase = true)) "Dine-in" else "Pickup",
            tableNumber = sanitizedTable,
            pickupTime = sanitizedPickupTime,
            itemsSummaryJson = jsonString,
            subtotal = authoritativeSubtotal,
            discount = discount,
            tax = tax,
            serviceCharge = serviceCharge,
            total = grandTotal,
            paymentMethod = BillingConfig.DEFAULT_PAYMENT_METHOD,
            paymentStatus = BillingConfig.DEFAULT_PAYMENT_STATUS,
            receiptNumber = orderId,
            timestamp = System.currentTimeMillis(),
            status = "New",
            trackingToken = trackingToken
        )

        orderDao.insertOrder(orderEntity)
        cartRepository.clearCart()

        // 5. Sync order and order items to Supabase cloud backend in real-time
        try {
            supabaseOrderService.saveOrderToSupabase(orderEntity, verifiedSummaryItems)
        } catch (e: Exception) {
            Log.w("OrderRepository", "Non-blocking Supabase sync error: ${e.message}")
        }

        // Non-blocking Firestore sync fallback
        try {
            firestoreOrderService.saveOrderToFirestore(orderEntity)
        } catch (e: Exception) {
            // Non-blocking fallback
        }

        return Result.success(
            OrderPlacementResult(
                orderId = orderId,
                trackingToken = trackingToken,
                verifiedSubtotal = authoritativeSubtotal,
                total = grandTotal
            )
        )
    }

    fun parseOrderItems(json: String): List<OrderItemSummary> {
        return try {
            jsonAdapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun updateOrderStatus(
        orderId: String,
        newStatus: String,
        isAuthorizedAdmin: Boolean,
        adminToken: String? = null
    ): Result<Unit> {
        if (!isAuthorizedAdmin) {
            return Result.failure(SecurityException("Unauthorized: Admin authentication required to update order status."))
        }
        val sanitizedId = SecurityUtils.sanitizeInput(orderId)
        val sanitizedStatus = SecurityUtils.sanitizeInput(newStatus)
        orderDao.updateOrderStatus(sanitizedId, sanitizedStatus)

        // Update in Supabase real-time
        try {
            supabaseOrderService.updateOrderStatus(sanitizedId, sanitizedStatus, adminToken)
        } catch (e: Exception) {
            Log.w("OrderRepository", "Supabase update status fallback: ${e.message}")
        }

        try {
            firestoreOrderService.updateOrderStatus(sanitizedId, sanitizedStatus)
        } catch (e: Exception) {
            // Non-blocking
        }
        return Result.success(Unit)
    }


    suspend fun updatePaymentStatus(
        orderId: String,
        newPaymentStatus: String,
        isAuthorizedAdmin: Boolean,
        adminToken: String? = null
    ): Result<Unit> {
        if (!isAuthorizedAdmin) {
            return Result.failure(SecurityException("Unauthorized: Admin authentication required to update payment status."))
        }
        val sanitizedId = SecurityUtils.sanitizeInput(orderId)
        val sanitizedStatus = SecurityUtils.sanitizeInput(newPaymentStatus)
        orderDao.updatePaymentStatus(sanitizedId, sanitizedStatus)
        try {
            supabaseOrderService.updatePaymentStatus(sanitizedId, sanitizedStatus, adminToken)
        } catch (e: Exception) {
            Log.w("OrderRepository", "Supabase payment status fallback: ${e.message}")
        }
        try {
            firestoreOrderService.updatePaymentStatus(sanitizedId, sanitizedStatus)
        } catch (e: Exception) {
            Log.w("OrderRepository", "Firestore payment status fallback: ${e.message}")
        }
        return Result.success(Unit)
    }

    suspend fun deleteOrder(
        orderId: String,
        isAuthorizedAdmin: Boolean,
        adminToken: String? = null
    ): Result<Unit> {
        if (!isAuthorizedAdmin) {
            return Result.failure(SecurityException("Unauthorized: Admin authentication required to cancel or delete order."))
        }
        val sanitizedId = SecurityUtils.sanitizeInput(orderId)
        orderDao.deleteOrder(sanitizedId)

        // Delete from Supabase
        try {
            supabaseOrderService.deleteOrder(sanitizedId, adminToken)
        } catch (e: Exception) {
            Log.w("OrderRepository", "Supabase delete fallback: ${e.message}")
        }

        try {
            firestoreOrderService.deleteOrder(sanitizedId)
        } catch (e: Exception) {
            // Non-blocking
        }
        return Result.success(Unit)
    }
}

