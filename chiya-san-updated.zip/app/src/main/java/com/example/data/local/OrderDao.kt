package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderDao {
    @Query("SELECT * FROM past_orders ORDER BY timestamp DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)

    @Query("SELECT * FROM past_orders WHERE orderId = :orderId")
    suspend fun getOrderById(orderId: String): OrderEntity?

    @Query("SELECT * FROM past_orders WHERE orderId = :orderId AND trackingToken = :trackingToken")
    suspend fun getOrderByIdAndToken(orderId: String, trackingToken: String): OrderEntity?

    @Query("SELECT * FROM past_orders WHERE orderId IN (:orderIds) ORDER BY timestamp DESC")
    fun getOrdersByIds(orderIds: List<String>): Flow<List<OrderEntity>>

    @Query("UPDATE past_orders SET status = :status WHERE orderId = :orderId")
    suspend fun updateOrderStatus(orderId: String, status: String)

    @Query("UPDATE past_orders SET paymentStatus = :paymentStatus WHERE orderId = :orderId")
    suspend fun updatePaymentStatus(orderId: String, paymentStatus: String)

    @Query("DELETE FROM past_orders WHERE orderId = :orderId")
    suspend fun deleteOrder(orderId: String)
}
