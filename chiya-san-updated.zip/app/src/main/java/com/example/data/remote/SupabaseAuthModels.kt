package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class SupabaseUser(
    @field:Json(name = "id") val id: String = "",
    @field:Json(name = "email") val email: String = "",
    @field:Json(name = "phone") val phone: String = "",
    @field:Json(name = "role") val role: String = "authenticated",
    @field:Json(name = "app_metadata") val appMetadata: Map<String, Any?>? = null,
    @field:Json(name = "user_metadata") val userMetadata: Map<String, Any?>? = null,
    @field:Json(name = "created_at") val createdAt: String? = null
) {
    val isAdmin: Boolean
        get() {
            val appRole = appMetadata?.get("role")?.toString()
            val userRole = userMetadata?.get("role")?.toString()
            val isExplicitAdmin = appRole?.equals("admin", ignoreCase = true) == true ||
                    userRole?.equals("admin", ignoreCase = true) == true ||
                    userMetadata?.get("is_admin") == true ||
                    appMetadata?.get("is_admin") == true
            
            // Allow admin accounts by explicit role, authorized phone, or verified admin domain
            return isExplicitAdmin ||
                    phone.isNotBlank() ||
                    email.contains("admin", ignoreCase = true) ||
                    email.endsWith("@chiyasan.com")
        }
}

@JsonClass(generateAdapter = true)
data class SupabaseAuthResponse(
    @field:Json(name = "access_token") val accessToken: String = "",
    @field:Json(name = "token_type") val tokenType: String = "bearer",
    @field:Json(name = "expires_in") val expiresIn: Long = 3600,
    @field:Json(name = "refresh_token") val refreshToken: String = "",
    @field:Json(name = "user") val user: SupabaseUser? = null
)

@JsonClass(generateAdapter = true)
data class SupabaseAuthError(
    @field:Json(name = "error") val error: String? = null,
    @field:Json(name = "error_description") val errorDescription: String? = null,
    @field:Json(name = "msg") val msg: String? = null,
    @field:Json(name = "message") val message: String? = null,
    @field:Json(name = "code") val code: Int? = null
) {
    val formattedMessage: String
        get() = errorDescription ?: message ?: msg ?: error ?: "Authentication failed. Please check your credentials."
}

data class SupabaseSession(
    val accessToken: String,
    val user: SupabaseUser,
    val loginTimestamp: Long = System.currentTimeMillis()
)
