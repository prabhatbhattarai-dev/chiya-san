package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "past_orders")
data class OrderEntity(
    @PrimaryKey val orderId: String,
    val customerName: String,
    val customerPhone: String,
    val orderType: String, // "Dine-in" or "Pickup"
    val tableNumber: String? = null,
    val pickupTime: String? = null,
    val itemsSummaryJson: String,
    val subtotal: Double,
    val discount: Double = 0.0,
    val tax: Double = 0.0,
    val serviceCharge: Double = 0.0,
    val total: Double = subtotal,
    val paymentMethod: String = "Pay at Counter (Cash / QR)",
    val paymentStatus: String = "Pending",
    val receiptNumber: String = orderId,
    val timestamp: Long,
    val status: String,
    val trackingToken: String = ""
)
