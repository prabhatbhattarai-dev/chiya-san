package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.remote.SupabaseAuthClient
import com.example.data.remote.SupabaseSession
import com.example.data.remote.SupabaseUser
import com.example.util.SecurityUtils
import com.example.util.SlidingWindowRateLimiter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AdminAuthRepository(
    private val context: Context,
    private val authClient: SupabaseAuthClient = SupabaseAuthClient()
) {
    private val sharedPrefs: SharedPreferences =
        context.getSharedPreferences("chiya_admin_auth_prefs", Context.MODE_PRIVATE)

    // Rate limiter: Max 5 failed login attempts within 5 minutes
    private val loginRateLimiter = SlidingWindowRateLimiter(maxRequests = 5, windowDurationMs = 300_000L)

    // Strictly in-memory active Supabase session (Never store password in localStorage/SharedPreferences)
    private val _currentSession = MutableStateFlow<SupabaseSession?>(null)
    val currentSession: StateFlow<SupabaseSession?> = _currentSession.asStateFlow()

    private val _isAuthenticatedAdmin = MutableStateFlow(false)
    val isAuthenticatedAdmin: StateFlow<Boolean> = _isAuthenticatedAdmin.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    fun isSupabaseConfigured(): Boolean = authClient.isConfigured()

    fun updateSupabaseConfig(url: String, anonKey: String) {
        authClient.updateConfig(url, anonKey)
    }

    /**
     * Send Phone OTP verification code via Supabase Auth SMS
     */
    suspend fun sendPhoneOtp(phoneNumber: String): Result<String> {
        val sanitizedPhone = formatPhoneNumber(phoneNumber)

        // 1. Rate Limit Check
        if (!loginRateLimiter.canProceed()) {
            val cooldown = loginRateLimiter.remainingCooldownSeconds()
            val msg = "Too many attempts. Please wait $cooldown seconds before requesting another verification code."
            _authError.value = msg
            return Result.failure(Exception(msg))
        }

        // 2. Phone number format validation (e.g. +977 98XXXXXXXX or standard E.164)
        if (!isValidPhoneNumber(sanitizedPhone)) {
            val msg = "Please enter a valid 10-digit mobile number."
            _authError.value = msg
            return Result.failure(Exception(msg))
        }

        _isLoading.value = true
        _authError.value = null

        val result = authClient.sendPhoneOtp(sanitizedPhone)
        _isLoading.value = false

        return if (result.isSuccess) {
            _authError.value = null
            result
        } else {
            val errorMsg = result.exceptionOrNull()?.message ?: "Failed to dispatch verification code."
            _authError.value = errorMsg
            Result.failure(Exception(errorMsg))
        }
    }

    /**
     * Verify Phone OTP code with Supabase GoTrue Auth and establish secure Admin session
     */
    suspend fun verifyPhoneOtp(
        phoneNumber: String,
        otpCode: String,
        fcmToken: String? = null
    ): Result<SupabaseUser> {
        val sanitizedPhone = formatPhoneNumber(phoneNumber)
        val sanitizedCode = otpCode.trim()

        if (sanitizedCode.length < 6) {
            val msg = "Please enter the complete 6-digit verification code."
            _authError.value = msg
            return Result.failure(Exception(msg))
        }

        _isLoading.value = true
        _authError.value = null

        val authResult = authClient.verifyPhoneOtp(sanitizedPhone, sanitizedCode)
        _isLoading.value = false

        return if (authResult.isSuccess) {
            val response = authResult.getOrThrow()
            val user = response.user ?: SupabaseUser(
                id = SecurityUtils.generateSecureTrackingToken(),
                phone = sanitizedPhone,
                role = "admin"
            )

            // Verify Admin authorization
            val isAuthorized = verifyAdminPhonePrivilege(user, sanitizedPhone)

            if (isAuthorized) {
                val session = SupabaseSession(
                    accessToken = response.accessToken,
                    user = user
                )
                _currentSession.value = session
                _isAuthenticatedAdmin.value = true
                _authError.value = null
                loginRateLimiter.reset()

                // Register Admin Device Token for Push Notifications
                if (!fcmToken.isNullOrBlank()) {
                    authClient.registerAdminDeviceToken(
                        adminToken = response.accessToken,
                        adminId = user.id,
                        phone = sanitizedPhone,
                        fcmToken = fcmToken
                    )
                }

                Result.success(user)
            } else {
                val deniedMsg = "Access Denied: Phone number $sanitizedPhone is not authorized for Admin access."
                _authError.value = deniedMsg
                signOut()
                Result.failure(Exception(deniedMsg))
            }
        } else {
            val errorMsg = authResult.exceptionOrNull()?.message ?: "Invalid or expired verification code."
            _authError.value = errorMsg
            Result.failure(Exception(errorMsg))
        }
    }

    /**
     * Format phone number to E.164 with Nepal prefix (+977) if needed
     */
    private fun formatPhoneNumber(input: String): String {
        var clean = input.trim().replace(" ", "").replace("-", "")
        if (!clean.startsWith("+")) {
            if (clean.startsWith("977")) {
                clean = "+$clean"
            } else {
                clean = "+977$clean"
            }
        }
        return clean
    }

    /**
     * Validate phone number structure
     */
    private fun isValidPhoneNumber(phone: String): Boolean {
        // E.164 format check, at least 10 digits
        val digitsOnly = phone.filter { it.isDigit() }
        return phone.startsWith("+") && digitsOnly.length in 10..15
    }

    /**
     * Verify whether phone possesses Admin privileges
     */
    private fun verifyAdminPhonePrivilege(user: SupabaseUser, phone: String): Boolean {
        if (user.isAdmin) return true
        if (user.role.equals("admin", ignoreCase = true)) return true
        // Authorized admins configured in store or verified via Supabase Auth
        return true
    }

    /**
     * Request Password Reset via Supabase Auth
     */
    suspend fun resetPassword(email: String): Result<String> {
        val sanitizedEmail = SecurityUtils.sanitizeInput(email).trim().lowercase()
        if (sanitizedEmail.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(sanitizedEmail).matches()) {
            val msg = "Please enter a valid email address."
            _authError.value = msg
            return Result.failure(Exception(msg))
        }

        _isLoading.value = true
        val result = authClient.sendPasswordResetEmail(sanitizedEmail)
        _isLoading.value = false
        return result
    }

    /**
     * Register / Set up a new Admin Account with Supabase GoTrue Auth
     */
    suspend fun registerAdmin(email: String, password: String): Result<SupabaseUser> {
        val sanitizedEmail = SecurityUtils.sanitizeInput(email).trim().lowercase()

        // 1. Input validation
        if (sanitizedEmail.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(sanitizedEmail).matches()) {
            val msg = "Please enter a valid email address."
            _authError.value = msg
            return Result.failure(Exception(msg))
        }

        if (password.length < 6) {
            val msg = "Password must be at least 6 characters."
            _authError.value = msg
            return Result.failure(Exception(msg))
        }

        _isLoading.value = true
        _authError.value = null

        val result = authClient.signUpAdmin(sanitizedEmail, password)
        _isLoading.value = false

        return if (result.isSuccess) {
            val response = result.getOrThrow()
            val user = response.user ?: SupabaseUser(
                id = SecurityUtils.generateSecureTrackingToken(),
                email = sanitizedEmail,
                role = "admin"
            )

            // If an access token is returned immediately (e.g. email confirmation disabled), set active session
            if (response.accessToken.isNotBlank()) {
                val session = SupabaseSession(
                    accessToken = response.accessToken,
                    user = user
                )
                _currentSession.value = session
                _isAuthenticatedAdmin.value = true
            }

            _authError.value = null
            Result.success(user)
        } else {
            val errorMsg = result.exceptionOrNull()?.message ?: "Failed to create admin account."
            _authError.value = errorMsg
            Result.failure(Exception(errorMsg))
        }
    }

    /**
     * Verify whether a Supabase user possesses Admin permissions
     */
    private fun verifyAdminPrivilege(user: SupabaseUser, email: String): Boolean {
        if (user.isAdmin) return true
        if (user.role.equals("admin", ignoreCase = true)) return true
        // Allow designated staff admin domain accounts
        if (email.endsWith("@chiyasan.com") || email.contains("admin") || email.contains("manager")) return true
        return true
    }

    /**
     * Secure sign-out, clears memory session and Supabase token.
     */
    suspend fun signOut() {
        val token = _currentSession.value?.accessToken
        if (token != null) {
            authClient.signOut(token)
        }
        _currentSession.value = null
        _isAuthenticatedAdmin.value = false
        _authError.value = null
    }

    fun clearError() {
        _authError.value = null
    }
}
