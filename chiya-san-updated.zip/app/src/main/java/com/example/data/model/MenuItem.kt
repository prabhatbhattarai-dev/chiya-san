package com.example.data.model

data class MomoVariant(
    val name: String,
    val price: Double
)

data class MenuItem(
    val id: String,
    val name: String,
    val nepaliName: String? = null,
    val category: String,
    val price: Double,
    val description: String? = null,
    val hasVariants: Boolean = false,
    val variants: List<MomoVariant>? = null,
    val hasFlavours: Boolean = false,
    val flavours: List<String>? = null,
    val unit: String? = null
)

enum class OrderType {
    DINE_IN,
    PICKUP
}

data class CartItem(
    val id: Int = 0,
    val menuItemId: String,
    val name: String,
    val category: String,
    val selectedVariant: String? = null,
    val selectedFlavour: String? = null,
    val unitPrice: Double,
    val quantity: Int
) {
    val totalPrice: Double
        get() = unitPrice * quantity
}

data class OrderItemSummary(
    val name: String,
    val variant: String? = null,
    val flavour: String? = null,
    val unitPrice: Double,
    val quantity: Int
) {
    val totalPrice: Double
        get() = unitPrice * quantity
}
