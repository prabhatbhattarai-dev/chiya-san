package com.example.data.repository

import com.example.data.model.MenuItem
import com.example.data.model.MomoVariant

class MenuRepository {

    val categories = listOf(
        "All",
        "Momo",
        "Tea",
        "Coffee",
        "Shakes & Lassi",
        "Cold Drinks",
        "Food",
        "Snacks",
        "Bakery",
        "Ice Cream",
        "Smoke"
    )

    private val hookahFlavours = listOf("Mint", "Blueberry", "Peach", "Kiwi")

    private var _dynamicMenuItems: List<MenuItem>? = null

    val menuItems: List<MenuItem>
        get() = _dynamicMenuItems ?: defaultMenuItems

    fun updateMenuItems(items: List<MenuItem>) {
        if (items.isNotEmpty()) {
            _dynamicMenuItems = items
        }
    }

    private val defaultMenuItems: List<MenuItem> = listOf(
        // MOMO
        MenuItem(
            id = "momo_chicken",
            name = "Chicken Momo",
            category = "Momo",
            price = 200.0,
            description = "Handcrafted chicken dumplings served with signature house pickle",
            hasVariants = true,
            variants = listOf(
                MomoVariant("Steam", 200.0),
                MomoVariant("Fry", 220.0),
                MomoVariant("Jhol", 230.0),
                MomoVariant("Kothe", 250.0),
                MomoVariant("Sadeko", 280.0)
            )
        ),
        MenuItem(
            id = "momo_veg_paneer",
            name = "Veg & Paneer Momo",
            category = "Momo",
            price = 180.0,
            description = "Freshly steamed vegetable and paneer dumplings",
            hasVariants = true,
            variants = listOf(
                MomoVariant("Steam", 180.0),
                MomoVariant("Fry", 200.0),
                MomoVariant("Jhol", 210.0),
                MomoVariant("Kothe", 230.0),
                MomoVariant("Sadeko", 250.0)
            )
        ),

        // MILK TEA
        MenuItem(
            id = "tea_milk_normal",
            name = "Normal Milk Tea",
            nepaliName = "दुध चिया",
            category = "Tea",
            price = 35.0,
            description = "Traditional spiced Nepali milk tea brewed fresh"
        ),
        MenuItem(
            id = "tea_milk_honey",
            name = "Honey Milk Tea",
            nepaliName = "दुध चिया",
            category = "Tea",
            price = 50.0,
            description = "Classic milk tea sweetened with natural honey"
        ),
        MenuItem(
            id = "tea_milk_masala",
            name = "Masala Milk Tea",
            nepaliName = "दुध चिया",
            category = "Tea",
            price = 55.0,
            description = "Infused with aromatic cardamoms, cloves and spices"
        ),
        MenuItem(
            id = "tea_milk_coconut",
            name = "Coconut Milk Tea",
            nepaliName = "दुध चिया",
            category = "Tea",
            price = 65.0,
            description = "Fragrant coconut infused spiced milk tea"
        ),
        MenuItem(
            id = "tea_milk_rose",
            name = "Rose Milk Tea",
            nepaliName = "दुध चिया",
            category = "Tea",
            price = 65.0,
            description = "Subtle rose petal aroma blended into creamy milk tea"
        ),

        // BLACK TEA
        MenuItem(
            id = "tea_black_normal",
            name = "Normal Black Tea",
            nepaliName = "कालो चिया",
            category = "Tea",
            price = 25.0,
            description = "Pure CTC black tea brewed to perfection"
        ),
        MenuItem(
            id = "tea_black_lemon",
            name = "Lemon Tea",
            nepaliName = "कालो चिया",
            category = "Tea",
            price = 30.0,
            description = "Refreshing black tea with a squeeze of fresh lemon"
        ),
        MenuItem(
            id = "tea_black_masala",
            name = "Masala Black Tea",
            nepaliName = "कालो चिया",
            category = "Tea",
            price = 35.0,
            description = "Bold black tea steeped with mountain spices"
        ),
        MenuItem(
            id = "tea_black_hot_lemon_ginger_honey",
            name = "Hot Lemon w/ Ginger Honey",
            nepaliName = "कालो चिया",
            category = "Tea",
            price = 120.0,
            description = "Soothing hot lemon drink infused with crushed ginger & raw honey"
        ),

        // HERBAL TEA
        MenuItem(
            id = "tea_herbal_lemongrass",
            name = "Lemon Grass Tea",
            category = "Tea",
            price = 60.0,
            description = "Aromatic lemongrass brew with citrus herbal notes"
        ),
        MenuItem(
            id = "tea_herbal_rosemary",
            name = "Rosemary Tea",
            category = "Tea",
            price = 60.0,
            description = "Earthy herbal tea with soothing rosemary essence"
        ),
        MenuItem(
            id = "tea_herbal_rhododendron",
            name = "Rhododendron Tea",
            category = "Tea",
            price = 60.0,
            description = "Nepal's national flower (Lali Gurans) herbal blend"
        ),
        MenuItem(
            id = "tea_herbal_hibiscus",
            name = "Hibiscus (Red Tea)",
            category = "Tea",
            price = 80.0,
            description = "Tart, floral ruby red tea rich in antioxidants"
        ),
        MenuItem(
            id = "tea_herbal_mix",
            name = "Mix Herbal Tea",
            category = "Tea",
            price = 150.0,
            description = "Revitalizing blend of Mint + Lemon Grass + Rosemary"
        ),

        // FOOD
        MenuItem(
            id = "food_paneer_wrap",
            name = "Paneer Wrap",
            category = "Food",
            price = 350.0,
            description = "Grilled paneer wrap with crunchy veggies & sauce"
        ),
        MenuItem(
            id = "food_chicken_wrap",
            name = "Chicken Wrap",
            category = "Food",
            price = 380.0,
            description = "Tender spiced chicken encased in a warm tortilla wrap"
        ),
        MenuItem(
            id = "food_veg_waiwai_sadeko",
            name = "Veg Wai-Wai Sadeko",
            category = "Food",
            price = 160.0,
            description = "Classic crunchy Wai-Wai tossed with onions, tomatoes & chili"
        ),
        MenuItem(
            id = "food_sausage_waiwai_sadeko",
            name = "Sausage Wai-Wai Sadeko",
            category = "Food",
            price = 210.0,
            description = "Wai-Wai sadeko garnished with sliced fried sausages"
        ),
        MenuItem(
            id = "food_veg_waiwai_fry",
            name = "Veg Wai-Wai Fry",
            category = "Food",
            price = 120.0,
            description = "Pan-fried noodles tossed with fresh garden vegetables"
        ),
        MenuItem(
            id = "food_sausage_waiwai_fry",
            name = "Sausage Wai-Wai Fry",
            category = "Food",
            price = 180.0,
            description = "Pan-fried Wai-Wai noodles with juicy sausage chunks"
        ),
        MenuItem(
            id = "food_chicken_waiwai_fry",
            name = "Chicken Wai-Wai Fry",
            category = "Food",
            price = 190.0,
            description = "Stir-fried Wai-Wai noodles loaded with shredded chicken"
        ),
        MenuItem(
            id = "food_veg_sandwich",
            name = "Veg Sandwich",
            category = "Food",
            price = 180.0,
            description = "Double-decker grilled sandwich with fresh veggies & mayo"
        ),
        MenuItem(
            id = "food_chicken_sandwich",
            name = "Chicken Sandwich",
            category = "Food",
            price = 250.0,
            description = "Toasted sandwich stuffed with savory chicken filling"
        ),

        // BAKERY
        MenuItem(
            id = "bakery_khajuri_puff",
            name = "Khajuri Puff",
            unit = "per pcs",
            category = "Bakery",
            price = 10.0,
            description = "Flaky, buttery sweet pastry puff"
        ),
        MenuItem(
            id = "bakery_local_donut",
            name = "Local Donut",
            category = "Bakery",
            price = 20.0,
            description = "Traditional Nepali house-baked ring donut"
        ),
        MenuItem(
            id = "bakery_peanut_macaruns",
            name = "Peanut Macaruns",
            category = "Bakery",
            price = 20.0,
            description = "Crunchy, sweet peanut macaroon biscuits"
        ),
        MenuItem(
            id = "bakery_disco_chips_cookies",
            name = "Disco Chips Cookies",
            unit = "4 pcs",
            category = "Bakery",
            price = 50.0,
            description = "Pack of 4 delicious chocolate chip biscuits"
        ),

        // SHAKE
        MenuItem(
            id = "shake_banana",
            name = "Banana Shake",
            category = "Shakes & Lassi",
            price = 210.0,
            description = "Creamy blend of ripe bananas and cold milk"
        ),
        MenuItem(
            id = "shake_chocolate",
            name = "Chocolate Shake",
            category = "Shakes & Lassi",
            price = 250.0,
            description = "Rich chocolate milk shake topped with cocoa dust"
        ),
        MenuItem(
            id = "shake_oreo",
            name = "Oreo Shake",
            category = "Shakes & Lassi",
            price = 280.0,
            description = "Thick milk shake blended with crushed Oreo cookies"
        ),
        MenuItem(
            id = "shake_strawberry",
            name = "Strawberry Shake",
            category = "Shakes & Lassi",
            price = 300.0,
            description = "Sweet and tangy strawberry milk shake"
        ),

        // LASSI
        MenuItem(
            id = "lassi_plain",
            name = "Plain Lassi",
            category = "Shakes & Lassi",
            price = 180.0,
            description = "Traditional churned curd drink with sweet cardamom flavor"
        ),
        MenuItem(
            id = "lassi_banana",
            name = "Banana Lassi",
            category = "Shakes & Lassi",
            price = 210.0,
            description = "Thick yogurt shake infused with fresh bananas"
        ),
        MenuItem(
            id = "lassi_chocolate",
            name = "Chocolate Lassi",
            category = "Shakes & Lassi",
            price = 280.0,
            description = "Indulgent cocoa twist on fresh sweet lassi"
        ),

        // COLD BEVERAGE
        MenuItem(
            id = "cold_lemon_tea",
            name = "Cold Lemon Tea",
            category = "Cold Drinks",
            price = 80.0,
            description = "Chilled lemon iced tea served over ice"
        ),
        MenuItem(
            id = "cold_masala_coke",
            name = "Masala Coke",
            category = "Cold Drinks",
            price = 100.0,
            description = "Chilled Coca-Cola spiced with black salt and lemon"
        ),
        MenuItem(
            id = "cold_lemon_sprite",
            name = "Lemon Sprite",
            category = "Cold Drinks",
            price = 130.0,
            description = "Crisp Sprite with freshly squeezed lemon juice"
        ),
        MenuItem(
            id = "cold_virgin_mojito",
            name = "Virgin Mojito",
            category = "Cold Drinks",
            price = 150.0,
            description = "Sparkling mint & lime refresher over crushed ice"
        ),
        MenuItem(
            id = "cold_lemonade",
            name = "Lemonade",
            category = "Cold Drinks",
            price = 200.0,
            description = "Freshly pressed lemon cooler"
        ),
        MenuItem(
            id = "cold_mint_lemonade",
            name = "Mint Lemonade",
            category = "Cold Drinks",
            price = 210.0,
            description = "Freshly pressed lemonade muddled with garden mint"
        ),

        // COFFEE
        MenuItem(
            id = "coffee_iced_americano",
            name = "Iced Americano",
            category = "Coffee",
            price = 150.0,
            description = "Double shot espresso poured over cold water & ice"
        ),
        MenuItem(
            id = "coffee_iced_milk",
            name = "Iced Milk Coffee",
            category = "Coffee",
            price = 180.0,
            description = "Smooth espresso blended with chilled milk & ice"
        ),

        // ICE CREAM
        MenuItem(
            id = "icecream_vanilla",
            name = "Vanilla Ice Cream",
            category = "Ice Cream",
            price = 150.0,
            description = "Classic creamy vanilla scoop"
        ),
        MenuItem(
            id = "icecream_strawberry",
            name = "Strawberry Ice Cream",
            category = "Ice Cream",
            price = 150.0,
            description = "Sweet strawberry ice cream scoop"
        ),
        MenuItem(
            id = "icecream_chocolate",
            name = "Chocolate Ice Cream",
            category = "Ice Cream",
            price = 150.0,
            description = "Decadent dark chocolate scoop"
        ),

        // QUICK SNACKS
        MenuItem(
            id = "snacks_veg_pakoda",
            name = "Veg Pakoda",
            category = "Snacks",
            price = 150.0,
            description = "Crispy golden vegetable fritters served hot"
        ),
        MenuItem(
            id = "snacks_french_fries",
            name = "French Fries",
            category = "Snacks",
            price = 160.0,
            description = "Golden potato fries lightly salted with ketchup dip"
        ),
        MenuItem(
            id = "snacks_finger_chop",
            name = "Finger Chop",
            category = "Snacks",
            price = 180.0,
            description = "Savory spiced vegetable finger croquettes"
        ),
        MenuItem(
            id = "snacks_spicy_fries",
            name = "Spicy Fries",
            category = "Snacks",
            price = 200.0,
            description = "Crispy potato fries tossed in peri-peri chili mix"
        ),

        // SAUSAGE
        MenuItem(
            id = "sausage_boiled",
            name = "Boiled Sausage",
            category = "Snacks",
            price = 60.0,
            description = "Single tender boiled chicken sausage"
        ),
        MenuItem(
            id = "sausage_fry",
            name = "Sausage Fry",
            category = "Snacks",
            price = 60.0,
            description = "Single pan-fried crispy sausage"
        ),
        MenuItem(
            id = "sausage_sadeko",
            name = "Sausage Sadeko",
            category = "Snacks",
            price = 340.0,
            description = "Sliced sausages tossed with nepali herbs, onions & chili"
        ),

        // SMOKE
        MenuItem(
            id = "smoke_normal_hookah",
            name = "Normal Hookah",
            category = "Smoke",
            price = 350.0,
            description = "Smooth shisha bowl with your choice of flavour",
            hasFlavours = true,
            flavours = hookahFlavours
        ),
        MenuItem(
            id = "smoke_special_hookah",
            name = "Special Hookah",
            category = "Smoke",
            price = 550.0,
            description = "Premium ice-cooled shisha bowl with choice of flavour",
            hasFlavours = true,
            flavours = hookahFlavours
        ),
        MenuItem(
            id = "smoke_shikhar_ice",
            name = "Shikhar Ice Cigarette",
            category = "Smoke",
            price = 20.0,
            description = "Single stick Shikhar Ice"
        ),
        MenuItem(
            id = "smoke_surya_red",
            name = "Surya Red Cigarette",
            category = "Smoke",
            price = 25.0,
            description = "Single stick Surya Red"
        ),
        MenuItem(
            id = "smoke_surya_light",
            name = "Surya Light Cigarette",
            category = "Smoke",
            price = 25.0,
            description = "Single stick Surya Light"
        ),
        MenuItem(
            id = "smoke_surya_arctic",
            name = "Surya Arctic Cigarette",
            category = "Smoke",
            price = 25.0,
            description = "Single stick Surya Arctic"
        ),
        MenuItem(
            id = "smoke_black",
            name = "Black Cigarette",
            category = "Smoke",
            price = 30.0,
            description = "Single stick Black"
        )
    )

    fun getItemsByCategory(category: String, query: String = ""): List<MenuItem> {
        return menuItems.filter { item ->
            val matchesCategory = when (category) {
                "All" -> true
                "Tea" -> item.category == "Tea"
                "Shakes & Lassi" -> item.category == "Shakes & Lassi"
                "Cold Drinks" -> item.category == "Cold Drinks"
                "Snacks" -> item.category == "Snacks"
                else -> item.category.equals(category, ignoreCase = true)
            }
            val matchesQuery = query.isEmpty() ||
                    item.name.contains(query, ignoreCase = true) ||
                    (item.nepaliName?.contains(query, ignoreCase = true) == true) ||
                    (item.description?.contains(query, ignoreCase = true) == true)

            matchesCategory && matchesQuery
        }
    }
}
