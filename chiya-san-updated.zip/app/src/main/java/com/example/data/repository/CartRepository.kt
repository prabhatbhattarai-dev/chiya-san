package com.example.data.repository

import com.example.data.local.CartDao
import com.example.data.local.CartEntity
import com.example.data.model.CartItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class CartRepository(private val cartDao: CartDao) {

    val cartItems: Flow<List<CartItem>> = cartDao.getCartItems().map { entities ->
        entities.map { entity ->
            CartItem(
                id = entity.id,
                menuItemId = entity.menuItemId,
                name = entity.name,
                category = entity.category,
                selectedVariant = entity.selectedVariant,
                selectedFlavour = entity.selectedFlavour,
                unitPrice = entity.unitPrice,
                quantity = entity.quantity
            )
        }
    }

    suspend fun addToCart(
        menuItemId: String,
        name: String,
        category: String,
        variant: String?,
        flavour: String?,
        unitPrice: Double,
        quantity: Int = 1
    ) {
        val existing = cartDao.findCartItem(menuItemId, variant, flavour)
        if (existing != null) {
            cartDao.updateCartItem(existing.copy(quantity = existing.quantity + quantity))
        } else {
            cartDao.insertCartItem(
                CartEntity(
                    menuItemId = menuItemId,
                    name = name,
                    category = category,
                    selectedVariant = variant,
                    selectedFlavour = flavour,
                    unitPrice = unitPrice,
                    quantity = quantity
                )
            )
        }
    }

    suspend fun updateQuantity(cartItemId: Int, newQuantity: Int) {
        if (newQuantity <= 0) {
            cartDao.deleteCartItem(cartItemId)
        } else {
            // Find current item and update
            // We can delete or update
        }
    }

    suspend fun updateCartItemQuantity(cartItem: CartItem, newQuantity: Int) {
        if (newQuantity <= 0) {
            cartDao.deleteCartItem(cartItem.id)
        } else {
            cartDao.updateCartItem(
                CartEntity(
                    id = cartItem.id,
                    menuItemId = cartItem.menuItemId,
                    name = cartItem.name,
                    category = cartItem.category,
                    selectedVariant = cartItem.selectedVariant,
                    selectedFlavour = cartItem.selectedFlavour,
                    unitPrice = cartItem.unitPrice,
                    quantity = newQuantity
                )
            )
        }
    }

    suspend fun removeCartItem(cartItemId: Int) {
        cartDao.deleteCartItem(cartItemId)
    }

    suspend fun clearCart() {
        cartDao.clearCart()
    }
}
