package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CartDao {
    @Query("SELECT * FROM cart_items ORDER BY id ASC")
    fun getCartItems(): Flow<List<CartEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartItem(item: CartEntity)

    @Query("SELECT * FROM cart_items WHERE menuItemId = :menuItemId AND (selectedVariant = :variant OR (selectedVariant IS NULL AND :variant IS NULL)) AND (selectedFlavour = :flavour OR (selectedFlavour IS NULL AND :flavour IS NULL)) LIMIT 1")
    suspend fun findCartItem(menuItemId: String, variant: String?, flavour: String?): CartEntity?

    @Update
    suspend fun updateCartItem(item: CartEntity)

    @Query("DELETE FROM cart_items WHERE id = :id")
    suspend fun deleteCartItem(id: Int)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()
}
