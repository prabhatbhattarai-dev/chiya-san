package com.example.data.remote

import android.net.Uri
import android.util.Log
import com.example.BuildConfig

/**
 * Authoritative Supabase Client Configuration for Chiya San.
 * Uses only the Project URL and Publishable/Anon Key.
 */
object SupabaseClientConfig {
    const val DEFAULT_PROJECT_URL = "https://aghwptodbtcibazudp.supabase.co"
    const val DEFAULT_PUBLISHABLE_KEY = "sb_publishable_UUIcwbZe9ZY22v6S7Iko1g_LYkTwhoM"

    private var customUrl: String? = null
    private var customAnonKey: String? = null

    fun setCustomCredentials(url: String?, anonKey: String?) {
        if (!url.isNullOrBlank()) customUrl = url.trim().trimEnd('/')
        if (!anonKey.isNullOrBlank()) customAnonKey = anonKey.trim()
    }

    fun getSupabaseUrl(): String {
        val override = customUrl
        if (!override.isNullOrBlank()) return override

        val buildConfigUrl = try {
            val field = BuildConfig::class.java.getField("SUPABASE_URL")
            (field.get(null) as? String)?.trim()?.trimEnd('/')
        } catch (e: Exception) {
            null
        }

        return if (!buildConfigUrl.isNullOrBlank() && !buildConfigUrl.contains("placeholder")) {
            buildConfigUrl
        } else {
            DEFAULT_PROJECT_URL
        }
    }

    fun getSupabaseAnonKey(): String {
        val override = customAnonKey
        if (!override.isNullOrBlank()) return override

        val buildConfigKey = try {
            val field = BuildConfig::class.java.getField("SUPABASE_ANON_KEY")
            (field.get(null) as? String)?.trim()
        } catch (e: Exception) {
            null
        }

        return if (!buildConfigKey.isNullOrBlank() && !buildConfigKey.contains("placeholder")) {
            buildConfigKey
        } else {
            DEFAULT_PUBLISHABLE_KEY
        }
    }

    fun getRestUrl(table: String): String {
        return "${getSupabaseUrl()}/rest/v1/$table"
    }

    fun getAuthUrl(endpoint: String): String {
        val cleanEndpoint = endpoint.trim().trimStart('/')
        return "${getSupabaseUrl()}/auth/v1/$cleanEndpoint"
    }

    fun getRealtimeWebSocketUrl(): String {
        val base = getSupabaseUrl()
        val anonKey = getSupabaseAnonKey()
        val uri = Uri.parse(base)
        val host = uri.host ?: "aghwptodbtcibazudp.supabase.co"
        val scheme = if (base.startsWith("https://")) "wss" else "ws"
        return "$scheme://$host/realtime/v1/websocket?apikey=$anonKey&vsn=1.0.0"
    }

    fun isConfigured(): Boolean {
        val url = getSupabaseUrl()
        val key = getSupabaseAnonKey()
        return url.isNotBlank() &&
               key.isNotBlank() &&
               !url.contains("placeholder") &&
               (url.startsWith("http://") || url.startsWith("https://"))
    }
}
