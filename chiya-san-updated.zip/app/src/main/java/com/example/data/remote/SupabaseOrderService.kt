package com.example.data.remote

import android.util.Log
import com.example.data.local.OrderEntity
import com.example.data.model.MenuItem
import com.example.data.model.MomoVariant
import com.example.data.model.OrderItemSummary
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Real-time Supabase Data & Realtime Service for Chiya San.
 * Handles Customer Orders, Order Items, Menu Items, Real-time sync, and Admin Status Management.
 */
class SupabaseOrderService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private fun getAuthHeaders(adminToken: String? = null): Map<String, String> {
        val anonKey = SupabaseClientConfig.getSupabaseAnonKey()
        val authBearer = if (!adminToken.isNullOrBlank()) adminToken else anonKey
        return mapOf(
            "apikey" to anonKey,
            "Authorization" to "Bearer $authBearer",
            "Content-Type" to "application/json",
            "Prefer" to "return=representation"
        )
    }

    /**
     * Save Customer Order and individual Order Items to Supabase via PostgREST
     */
    suspend fun saveOrderToSupabase(
        order: OrderEntity,
        items: List<OrderItemSummary>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (!SupabaseClientConfig.isConfigured()) {
            return@withContext Result.success(Unit)
        }

        try {
            val ordersEndpoint = SupabaseClientConfig.getRestUrl("orders")

            val orderPayload = JSONObject().apply {
                put("order_id", order.orderId)
                put("customer_name", order.customerName)
                put("customer_phone", order.customerPhone)
                put("order_type", order.orderType)
                put("table_number", order.tableNumber ?: JSONObject.NULL)
                put("pickup_time", order.pickupTime ?: JSONObject.NULL)
                put("items_summary_json", order.itemsSummaryJson)
                put("subtotal", order.subtotal)
                put("discount", order.discount)
                put("tax", order.tax)
                put("service_charge", order.serviceCharge)
                put("total", order.total)
                put("payment_method", order.paymentMethod)
                put("payment_status", order.paymentStatus)
                put("receipt_number", order.receiptNumber)
                put("status", order.status)
                put("timestamp", order.timestamp)
                put("tracking_token", order.trackingToken)
            }

            val requestBuilder = Request.Builder()
                .url(ordersEndpoint)
                .post(orderPayload.toString().toRequestBody(jsonMediaType))

            getAuthHeaders().forEach { (k, v) -> requestBuilder.addHeader(k, v) }

            val response = client.newCall(requestBuilder.build()).execute()
            if (!response.isSuccessful && response.code !in 200..299) {
                val err = response.body?.string() ?: ""
                Log.e("SupabaseOrderService", "Failed to save order to Supabase (HTTP ${response.code}): $err")
            } else {
                Log.d("SupabaseOrderService", "Order ${order.orderId} saved to Supabase successfully.")
            }

            // Also insert structured line items into order_items table
            if (items.isNotEmpty()) {
                saveOrderItemsToSupabase(order.orderId, items)
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SupabaseOrderService", "Error saving order to Supabase: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Save individual order items to 'order_items' table in Supabase
     */
    private suspend fun saveOrderItemsToSupabase(
        orderId: String,
        items: List<OrderItemSummary>
    ) = withContext(Dispatchers.IO) {
        try {
            val itemsEndpoint = SupabaseClientConfig.getRestUrl("order_items")
            val itemsArray = JSONArray()

            for (item in items) {
                val itemObj = JSONObject().apply {
                    put("order_id", orderId)
                    put("item_name", item.name)
                    put("variant", item.variant ?: JSONObject.NULL)
                    put("flavour", item.flavour ?: JSONObject.NULL)
                    put("unit_price", item.unitPrice)
                    put("quantity", item.quantity)
                    put("total_price", item.totalPrice)
                }
                itemsArray.put(itemObj)
            }

            val requestBuilder = Request.Builder()
                .url(itemsEndpoint)
                .post(itemsArray.toString().toRequestBody(jsonMediaType))

            getAuthHeaders().forEach { (k, v) -> requestBuilder.addHeader(k, v) }
            val response = client.newCall(requestBuilder.build()).execute()
            if (response.isSuccessful) {
                Log.d("SupabaseOrderService", "Saved ${items.size} order items for order $orderId.")
            }
        } catch (e: Exception) {
            Log.w("SupabaseOrderService", "Could not save order items: ${e.message}")
        }
    }

    /**
     * Fetch all remote orders from Supabase (for Admin & syncing)
     */
    suspend fun fetchOrdersFromSupabase(adminToken: String? = null): Result<List<OrderEntity>> = withContext(Dispatchers.IO) {
        if (!SupabaseClientConfig.isConfigured()) {
            return@withContext Result.success(emptyList())
        }

        try {
            val url = "${SupabaseClientConfig.getRestUrl("orders")}?select=*&order=timestamp.desc"
            val requestBuilder = Request.Builder().url(url).get()
            getAuthHeaders(adminToken).forEach { (k, v) -> requestBuilder.addHeader(k, v) }

            val response = client.newCall(requestBuilder.build()).execute()
            val body = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val jsonArray = JSONArray(body)
                val ordersList = mutableListOf<OrderEntity>()

                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val order = OrderEntity(
                        orderId = obj.optString("order_id", ""),
                        customerName = obj.optString("customer_name", "Guest"),
                        customerPhone = obj.optString("customer_phone", ""),
                        orderType = obj.optString("order_type", "Dine-in"),
                        tableNumber = if (obj.isNull("table_number")) null else obj.optString("table_number"),
                        pickupTime = if (obj.isNull("pickup_time")) null else obj.optString("pickup_time"),
                        itemsSummaryJson = obj.optString("items_summary_json", "[]"),
                        subtotal = obj.optDouble("subtotal", 0.0),
                        discount = obj.optDouble("discount", 0.0),
                        tax = obj.optDouble("tax", 0.0),
                        serviceCharge = obj.optDouble("service_charge", 0.0),
                        total = obj.optDouble("total", obj.optDouble("subtotal", 0.0)),
                        paymentMethod = obj.optString("payment_method", "Pay at Counter (Cash / QR)"),
                        paymentStatus = obj.optString("payment_status", "Pending"),
                        receiptNumber = obj.optString("receipt_number", obj.optString("order_id", "")),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        status = obj.optString("status", "New"),
                        trackingToken = obj.optString("tracking_token", "")
                    )
                    if (order.orderId.isNotBlank()) {
                        ordersList.add(order)
                    }
                }
                Result.success(ordersList)
            } else {
                Log.w("SupabaseOrderService", "Fetch orders returned HTTP ${response.code}: $body")
                Result.failure(Exception("Supabase HTTP ${response.code}: $body"))
            }
        } catch (e: Exception) {
            Log.e("SupabaseOrderService", "Failed to fetch orders from Supabase: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Update order status in Supabase (New → Accepted → Preparing → Ready → Completed → Cancelled)
     */
    suspend fun updateOrderStatus(
        orderId: String,
        newStatus: String,
        adminToken: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (!SupabaseClientConfig.isConfigured()) {
            return@withContext Result.success(Unit)
        }

        try {
            val url = "${SupabaseClientConfig.getRestUrl("orders")}?order_id=eq.$orderId"
            val payload = JSONObject().apply {
                put("status", newStatus)
            }

            val requestBuilder = Request.Builder()
                .url(url)
                .patch(payload.toString().toRequestBody(jsonMediaType))

            getAuthHeaders(adminToken).forEach { (k, v) -> requestBuilder.addHeader(k, v) }

            val response = client.newCall(requestBuilder.build()).execute()
            if (response.isSuccessful) {
                Log.d("SupabaseOrderService", "Updated order $orderId to status '$newStatus'")
                Result.success(Unit)
            } else {
                val err = response.body?.string() ?: ""
                Log.e("SupabaseOrderService", "Failed to update status on Supabase (HTTP ${response.code}): $err")
                Result.failure(Exception("HTTP ${response.code}: $err"))
            }
        } catch (e: Exception) {
            Log.e("SupabaseOrderService", "Error updating status on Supabase: ${e.message}", e)
            Result.failure(e)
        }
    }


    suspend fun updatePaymentStatus(
        orderId: String,
        newPaymentStatus: String,
        adminToken: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (!SupabaseClientConfig.isConfigured()) return@withContext Result.success(Unit)
        try {
            val url = "${SupabaseClientConfig.getRestUrl("orders")}?order_id=eq.$orderId"
            val payload = JSONObject().apply { put("payment_status", newPaymentStatus) }
            val requestBuilder = Request.Builder()
                .url(url)
                .patch(payload.toString().toRequestBody(jsonMediaType))
            getAuthHeaders(adminToken).forEach { (k, v) -> requestBuilder.addHeader(k, v) }
            val response = client.newCall(requestBuilder.build()).execute()
            if (response.isSuccessful) Result.success(Unit)
            else Result.failure(Exception("Supabase HTTP ${response.code}"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Delete / Cancel order in Supabase
     */
    suspend fun deleteOrder(
        orderId: String,
        adminToken: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (!SupabaseClientConfig.isConfigured()) {
            return@withContext Result.success(Unit)
        }

        try {
            val url = "${SupabaseClientConfig.getRestUrl("orders")}?order_id=eq.$orderId"
            val requestBuilder = Request.Builder().url(url).delete()
            getAuthHeaders(adminToken).forEach { (k, v) -> requestBuilder.addHeader(k, v) }

            val response = client.newCall(requestBuilder.build()).execute()
            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                val err = response.body?.string() ?: ""
                Result.failure(Exception("HTTP ${response.code}: $err"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Fetch dynamic Menu Items and Prices from Supabase 'menu_items' table
     */
    suspend fun fetchMenuItems(): Result<List<MenuItem>> = withContext(Dispatchers.IO) {
        if (!SupabaseClientConfig.isConfigured()) {
            return@withContext Result.success(emptyList())
        }

        try {
            val url = "${SupabaseClientConfig.getRestUrl("menu_items")}?select=*&order=category.asc,name.asc"
            val requestBuilder = Request.Builder().url(url).get()
            getAuthHeaders().forEach { (k, v) -> requestBuilder.addHeader(k, v) }

            val response = client.newCall(requestBuilder.build()).execute()
            val body = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val jsonArray = JSONArray(body)
                val items = mutableListOf<MenuItem>()

                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val id = obj.optString("id", "")
                    val name = obj.optString("name", "")
                    if (id.isBlank() || name.isBlank()) continue

                    val nepaliName = if (obj.isNull("nepali_name")) null else obj.optString("nepali_name")
                    val category = obj.optString("category", "Tea")
                    val price = obj.optDouble("price", 0.0)
                    val description = if (obj.isNull("description")) null else obj.optString("description")
                    val hasVariants = obj.optBoolean("has_variants", false)
                    val hasFlavours = obj.optBoolean("has_flavours", false)
                    val unit = if (obj.isNull("unit")) null else obj.optString("unit")

                    var variantsList: List<MomoVariant>? = null
                    if (hasVariants && !obj.isNull("variants_json")) {
                        try {
                            val vArray = JSONArray(obj.getString("variants_json"))
                            val vList = mutableListOf<MomoVariant>()
                            for (v in 0 until vArray.length()) {
                                val vObj = vArray.getJSONObject(v)
                                vList.add(MomoVariant(vObj.getString("name"), vObj.getDouble("price")))
                            }
                            variantsList = vList
                        } catch (e: Exception) {
                            // Fallback
                        }
                    }

                    var flavoursList: List<String>? = null
                    if (hasFlavours && !obj.isNull("flavours_json")) {
                        try {
                            val fArray = JSONArray(obj.getString("flavours_json"))
                            val fList = mutableListOf<String>()
                            for (f in 0 until fArray.length()) {
                                fList.add(fArray.getString(f))
                            }
                            flavoursList = fList
                        } catch (e: Exception) {
                            // Fallback
                        }
                    }

                    items.add(
                        MenuItem(
                            id = id,
                            name = name,
                            nepaliName = nepaliName,
                            category = category,
                            price = price,
                            description = description,
                            hasVariants = hasVariants,
                            variants = variantsList,
                            hasFlavours = hasFlavours,
                            flavours = flavoursList,
                            unit = unit
                        )
                    )
                }
                Result.success(items)
            } else {
                Result.failure(Exception("HTTP ${response.code}: $body"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Real-time stream of orders from Supabase combining Realtime WebSocket & polling sync
     */
    fun getRealTimeOrdersFlow(adminTokenProvider: () -> String? = { null }): Flow<List<OrderEntity>> = callbackFlow {
        var webSocket: WebSocket? = null
        var pollingJob: Job? = null
        val scope = CoroutineScope(Dispatchers.IO)

        fun triggerFetch() {
            scope.launch {
                val result = fetchOrdersFromSupabase(adminTokenProvider())
                if (result.isSuccess) {
                    val orders = result.getOrNull() ?: emptyList()
                    trySend(orders)
                }
            }
        }

        // Initial fetch
        triggerFetch()

        // 1. Setup Supabase Realtime WebSocket Connection
        try {
            val wsUrl = SupabaseClientConfig.getRealtimeWebSocketUrl()
            val wsRequest = Request.Builder().url(wsUrl).build()

            val listener = object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    Log.d("SupabaseOrderService", "Realtime WebSocket connected to Supabase.")
                    // Join orders channel
                    val joinMsg = JSONObject().apply {
                        put("topic", "realtime:public:orders")
                        put("event", "phx_join")
                        put("payload", JSONObject().apply {
                            put("config", JSONObject().apply {
                                put("broadcast", JSONObject().apply { put("self", true) })
                                put("presence", JSONObject().apply { put("key", "") })
                                put("postgres_changes", JSONArray().apply {
                                    put(JSONObject().apply {
                                        put("event", "*")
                                        put("schema", "public")
                                        put("table", "orders")
                                    })
                                })
                            })
                        })
                        put("ref", "1")
                    }
                    webSocket.send(joinMsg.toString())
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    try {
                        val json = JSONObject(text)
                        val event = json.optString("event")
                        if (event == "postgres_changes" || event == "INSERT" || event == "UPDATE" || event == "DELETE") {
                            Log.d("SupabaseOrderService", "Realtime order change detected: $event")
                            triggerFetch()
                        }
                    } catch (e: Exception) {
                        // ignore heartbeat / ack
                    }
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    Log.w("SupabaseOrderService", "Realtime WebSocket disconnected/failure: ${t.message}")
                }
            }

            webSocket = client.newWebSocket(wsRequest, listener)
        } catch (e: Exception) {
            Log.w("SupabaseOrderService", "Could not start Realtime WebSocket: ${e.message}")
        }

        // 2. Periodic sync fallback (every 8 seconds) to guarantee instant updates
        pollingJob = scope.launch {
            while (isActive) {
                delay(8_000L)
                triggerFetch()
            }
        }

        awaitClose {
            webSocket?.close(1000, "Flow closed")
            pollingJob?.cancel()
        }
    }
}
