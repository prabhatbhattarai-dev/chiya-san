package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cart_items")
data class CartEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val menuItemId: String,
    val name: String,
    val category: String,
    val selectedVariant: String? = null,
    val selectedFlavour: String? = null,
    val unitPrice: Double,
    val quantity: Int
)
