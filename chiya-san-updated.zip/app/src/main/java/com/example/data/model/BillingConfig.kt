package com.example.data.model

/**
 * Cafe billing configuration.
 *
 * Set VAT_RATE to 0.0 if the cafe is not VAT registered.
 * Nepal VAT is commonly 13% for VAT-registered businesses.
 */
object BillingConfig {
    const val VAT_RATE = 0.13
    const val SERVICE_CHARGE_RATE = 0.0
    const val DEFAULT_DISCOUNT = 0.0
    const val DEFAULT_PAYMENT_METHOD = "Pay at Counter (Cash / QR)"
    const val DEFAULT_PAYMENT_STATUS = "Pending"
}
