package com.example.data.remote

import android.util.Log
import com.example.data.local.OrderEntity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * Real-time Firestore service for Chiya San customer and admin order synchronization.
 */
class FirestoreOrderService {

    private fun getFirestoreSafe(): FirebaseFirestore? {
        return try {
            FirebaseFirestore.getInstance()
        } catch (t: Throwable) {
            Log.w("FirestoreOrderService", "FirebaseApp is not initialized; running in local/offline mode.")
            null
        }
    }

    /**
     * Save an order to Firestore in real-time
     */
    suspend fun saveOrderToFirestore(order: OrderEntity): Result<Unit> {
        val firestore = getFirestoreSafe() ?: return Result.success(Unit)
        return try {
            val orderMap = hashMapOf(
                "orderId" to order.orderId,
                "customerName" to order.customerName,
                "customerPhone" to order.customerPhone,
                "orderType" to order.orderType,
                "tableNumber" to (order.tableNumber ?: ""),
                "pickupTime" to (order.pickupTime ?: ""),
                "itemsSummaryJson" to order.itemsSummaryJson,
                "subtotal" to order.subtotal,
                "discount" to order.discount,
                "tax" to order.tax,
                "serviceCharge" to order.serviceCharge,
                "total" to order.total,
                "paymentMethod" to order.paymentMethod,
                "paymentStatus" to order.paymentStatus,
                "receiptNumber" to order.receiptNumber,
                "status" to order.status,
                "timestamp" to order.timestamp,
                "trackingToken" to order.trackingToken,
                "updatedAt" to System.currentTimeMillis()
            )

            firestore.collection("orders").document(order.orderId)
                .set(orderMap, SetOptions.merge())
                .await()

            Log.d("FirestoreOrderService", "Order ${order.orderId} saved to Firestore successfully.")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("FirestoreOrderService", "Failed to save order to Firestore: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Real-time stream of all orders from Firestore for Admin synchronization
     */
    fun getRealTimeOrdersFlow(): Flow<List<OrderEntity>> = callbackFlow {
        val firestore = getFirestoreSafe()
        if (firestore == null) {
            channel.close()
            return@callbackFlow
        }

        var listener: ListenerRegistration? = null
        try {
            listener = firestore.collection("orders")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e("FirestoreOrderService", "Firestore snapshot error: ${error.message}", error)
                        return@addSnapshotListener
                    }

                    if (snapshot != null) {
                        val orders = snapshot.documents.mapNotNull { doc ->
                            try {
                                val orderId = doc.getString("orderId") ?: doc.id
                                val customerName = doc.getString("customerName") ?: "Valued Customer"
                                val customerPhone = doc.getString("customerPhone") ?: ""
                                val orderType = doc.getString("orderType") ?: "Dine-in"
                                val tableNumber = doc.getString("tableNumber")?.takeIf { it.isNotBlank() }
                                val pickupTime = doc.getString("pickupTime")?.takeIf { it.isNotBlank() }
                                val itemsSummaryJson = doc.getString("itemsSummaryJson") ?: "[]"
                                val subtotal = doc.getDouble("subtotal") ?: 0.0
                                val discount = doc.getDouble("discount") ?: 0.0
                                val tax = doc.getDouble("tax") ?: 0.0
                                val serviceCharge = doc.getDouble("serviceCharge") ?: 0.0
                                val total = doc.getDouble("total") ?: (subtotal - discount + tax + serviceCharge)
                                val paymentMethod = doc.getString("paymentMethod") ?: "Pay at Counter (Cash / QR)"
                                val paymentStatus = doc.getString("paymentStatus") ?: "Pending"
                                val receiptNumber = doc.getString("receiptNumber") ?: orderId
                                val status = doc.getString("status") ?: "Order Placed"
                                val timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()
                                val trackingToken = doc.getString("trackingToken") ?: ""

                                OrderEntity(
                                    orderId = orderId,
                                    customerName = customerName,
                                    customerPhone = customerPhone,
                                    orderType = orderType,
                                    tableNumber = tableNumber,
                                    pickupTime = pickupTime,
                                    itemsSummaryJson = itemsSummaryJson,
                                    subtotal = subtotal,
                                    discount = discount,
                                    tax = tax,
                                    serviceCharge = serviceCharge,
                                    total = total,
                                    paymentMethod = paymentMethod,
                                    paymentStatus = paymentStatus,
                                    receiptNumber = receiptNumber,
                                    timestamp = timestamp,
                                    status = status,
                                    trackingToken = trackingToken
                                )
                            } catch (e: Exception) {
                                Log.e("FirestoreOrderService", "Error parsing Firestore doc ${doc.id}", e)
                                null
                            }
                        }
                        trySend(orders)
                    }
                }
        } catch (e: Exception) {
            Log.e("FirestoreOrderService", "Failed to attach snapshot listener", e)
        }

        awaitClose {
            listener?.remove()
        }
    }

    /**
     * Update order status in Firestore
     */
    suspend fun updateOrderStatus(orderId: String, newStatus: String): Result<Unit> {
        val firestore = getFirestoreSafe() ?: return Result.success(Unit)
        return try {
            firestore.collection("orders").document(orderId)
                .update(
                    mapOf(
                        "status" to newStatus,
                        "updatedAt" to System.currentTimeMillis()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("FirestoreOrderService", "Failed to update status in Firestore: ${e.message}", e)
            Result.failure(e)
        }
    }


    suspend fun updatePaymentStatus(orderId: String, newPaymentStatus: String): Result<Unit> {
        val firestore = getFirestoreSafe() ?: return Result.success(Unit)
        return try {
            firestore.collection("orders").document(orderId)
                .update(
                    mapOf(
                        "paymentStatus" to newPaymentStatus,
                        "updatedAt" to System.currentTimeMillis()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("FirestoreOrderService", "Failed to update payment status: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Delete / Cancel order in Firestore
     */
    suspend fun deleteOrder(orderId: String): Result<Unit> {
        val firestore = getFirestoreSafe() ?: return Result.success(Unit)
        return try {
            firestore.collection("orders").document(orderId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("FirestoreOrderService", "Failed to delete order from Firestore: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Register Admin FCM token in Firestore
     */
    suspend fun saveAdminFcmToken(token: String, deviceName: String = "Admin Android Device") {
        val firestore = getFirestoreSafe() ?: return
        try {
            val tokenData = hashMapOf(
                "token" to token,
                "deviceName" to deviceName,
                "platform" to "android",
                "registeredAt" to System.currentTimeMillis(),
                "role" to "admin"
            )
            firestore.collection("admin_fcm_tokens").document(token).set(tokenData, SetOptions.merge()).await()
            Log.d("FirestoreOrderService", "Admin FCM token registered in Firestore.")
        } catch (e: Exception) {
            Log.e("FirestoreOrderService", "Failed to save admin FCM token: ${e.message}")
        }
    }
}
