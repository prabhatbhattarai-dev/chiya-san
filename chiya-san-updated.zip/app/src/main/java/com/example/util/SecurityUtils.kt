package com.example.util

import java.security.MessageDigest
import java.security.SecureRandom

sealed class ValidationResult {
    object Valid : ValidationResult()
    data class Invalid(val errorMessage: String) : ValidationResult()

    val isValid: Boolean get() = this is Valid
}

object SecurityUtils {

    private val secureRandom = SecureRandom()

    /**
     * Generates a cryptographically strong, unpredictable 32-character hexadecimal tracking token.
     */
    fun generateSecureTrackingToken(): String {
        val bytes = ByteArray(16)
        secureRandom.nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    /**
     * Generates a 16-byte random cryptographic salt.
     */
    fun generateSalt(): String {
        val salt = ByteArray(16)
        secureRandom.nextBytes(salt)
        return salt.joinToString("") { "%02x".format(it) }
    }

    /**
     * Computes a SHA-256 hash of the input combined with salt.
     */
    fun hashWithSalt(input: String, saltHex: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(saltHex.toByteArray(Charsets.UTF_8))
        val digest = md.digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    /**
     * Constant-time comparison between two strings to prevent timing side-channel attacks.
     */
    fun slowEquals(a: String, b: String): Boolean {
        var diff = a.length xor b.length
        val minLen = minOf(a.length, b.length)
        for (i in 0 until minLen) {
            diff = diff or (a[i].code xor b[i].code)
        }
        return diff == 0
    }

    /**
     * Sanitizes plain user text input: strips null bytes, trims, eliminates control characters
     * and potential script/HTML markup tags to prevent injection and rendering anomalies.
     */
    fun sanitizeInput(input: String?): String {
        if (input == null) return ""
        return input
            .replace("\u0000", "")
            .replace("<", "")
            .replace(">", "")
            .replace("\"", "")
            .replace("'", "")
            .replace("\\", "")
            .trim()
    }

    /**
     * Validates customer name: length 2..50 characters, allowed characters: letters, spaces, hyphens, dots.
     */
    fun validateCustomerName(name: String): ValidationResult {
        val sanitized = sanitizeInput(name)
        if (sanitized.isBlank()) {
            return ValidationResult.Invalid("Customer name cannot be empty.")
        }
        if (sanitized.length < 2) {
            return ValidationResult.Invalid("Customer name is too short (min 2 characters).")
        }
        if (sanitized.length > 50) {
            return ValidationResult.Invalid("Customer name is too long (max 50 characters).")
        }
        // Allow unicode letters (supporting Devanagari/Nepali & English), spaces, dots, hyphens
        val nameRegex = Regex("^[\\p{L} .'-]+$")
        if (!nameRegex.matches(sanitized)) {
            return ValidationResult.Invalid("Customer name contains invalid characters.")
        }
        return ValidationResult.Valid
    }

    /**
     * Validates customer phone number:
     * Accepts Nepal 10-digit mobile (e.g. 98XXXXXXXX, 97XXXXXXXX), landline (01XXXXXXX),
     * or standard phone formats between 7 and 15 digits.
     */
    fun validatePhoneNumber(phone: String): ValidationResult {
        val sanitized = phone.replace(Regex("[^0-9+]"), "").trim()
        if (sanitized.isBlank()) {
            return ValidationResult.Invalid("Phone number cannot be empty.")
        }
        val digitsOnly = sanitized.removePrefix("+")
        if (digitsOnly.length !in 7..15) {
            return ValidationResult.Invalid("Phone number must be between 7 and 15 digits.")
        }
        // If 10 digits (standard Nepali mobile)
        if (digitsOnly.length == 10 && !digitsOnly.startsWith("98") && !digitsOnly.startsWith("97") && !digitsOnly.startsWith("96")) {
            // General valid format
            return ValidationResult.Valid
        }
        return ValidationResult.Valid
    }

    /**
     * Validates table number for Dine-in orders: must be an integer between 1 and 50.
     */
    fun validateTableNumber(table: String?): ValidationResult {
        if (table.isNullOrBlank()) {
            return ValidationResult.Invalid("Please specify a valid table number.")
        }
        val num = table.trim().toIntOrNull()
            ?: return ValidationResult.Invalid("Table number must be a valid integer.")
        if (num !in 1..50) {
            return ValidationResult.Invalid("Table number must be between 1 and 50.")
        }
        return ValidationResult.Valid
    }

    /**
     * Validates pickup time / instructions for Takeaway orders.
     */
    fun validatePickupTime(pickupTime: String?): ValidationResult {
        val sanitized = sanitizeInput(pickupTime)
        if (sanitized.isBlank()) {
            return ValidationResult.Invalid("Please provide an estimated pickup time.")
        }
        if (sanitized.length > 40) {
            return ValidationResult.Invalid("Pickup time note is too long (max 40 characters).")
        }
        return ValidationResult.Valid
    }

    /**
     * Masks customer phone number for privacy preservation in general views (e.g. 9841****12).
     */
    fun maskPhoneNumber(phone: String): String {
        val clean = phone.trim()
        if (clean.length <= 4) return "****"
        val prefixLen = 4.coerceAtMost(clean.length / 2)
        val suffixLen = 2.coerceAtMost(clean.length - prefixLen)
        val prefix = clean.take(prefixLen)
        val suffix = clean.takeLast(suffixLen)
        val maskedPart = "*".repeat(clean.length - prefixLen - suffixLen)
        return "$prefix$maskedPart$suffix"
    }
}

/**
 * Sliding-window rate limiter for protecting endpoints and state actions against automated spam/abuse.
 */
class SlidingWindowRateLimiter(
    private val maxRequests: Int,
    private val windowDurationMs: Long
) {
    private val timestamps = mutableListOf<Long>()

    @Synchronized
    fun canProceed(now: Long = System.currentTimeMillis()): Boolean {
        // Purge expired timestamps
        timestamps.removeAll { now - it > windowDurationMs }
        return if (timestamps.size < maxRequests) {
            timestamps.add(now)
            true
        } else {
            false
        }
    }

    @Synchronized
    fun remainingCooldownSeconds(now: Long = System.currentTimeMillis()): Int {
        timestamps.removeAll { now - it > windowDurationMs }
        if (timestamps.size < maxRequests) return 0
        val oldest = timestamps.minOrNull() ?: now
        val elapsed = now - oldest
        val remainingMs = (windowDurationMs - elapsed).coerceAtLeast(0)
        return ((remainingMs + 999) / 1000).toInt()
    }

    @Synchronized
    fun reset() {
        timestamps.clear()
    }
}
