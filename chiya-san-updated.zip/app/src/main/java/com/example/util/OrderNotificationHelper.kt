package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.OrderItemSummary

/**
 * Facebook Messenger / Urgent Order Alert style Notification Helper for Chiya San.
 * Creates prominent Heads-Up notifications with customer info, order number, items, and total price.
 */
object OrderNotificationHelper {
    const val CHANNEL_ID = "chiya_admin_orders_channel"
    private const val CHANNEL_NAME = "Admin Real-Time Order Alerts"
    private const val CHANNEL_DESC = "Heads-up push notifications for newly placed kitchen orders"

    const val EXTRA_NAVIGATE_TO = "NAVIGATE_TO"
    const val EXTRA_ORDER_ID = "ORDER_ID"
    const val VALUE_ADMIN_ORDERS = "ADMIN_ORDERS"

    /**
     * Create high-importance notification channel with vibration and sound
     */
    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                .build()

            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = CHANNEL_DESC
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 350, 150, 350, 150, 450)
                setSound(soundUri, audioAttributes)
                setShowBadge(true)
                lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            }

            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    /**
     * Display a rich, Facebook message-style push notification when a new order is received
     */
    fun showNewOrderPushNotification(
        context: Context,
        orderId: String,
        customerName: String,
        subtotal: Double,
        itemsList: List<OrderItemSummary> = emptyList(),
        itemsSummaryText: String? = null,
        orderType: String = "Dine-in",
        tableOrPickup: String? = null
    ) {
        if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) {
            Log.w("OrderNotificationHelper", "Notifications are disabled by user.")
            return
        }

        createNotificationChannel(context)

        // Intent to launch MainActivity and open Admin Orders screen
        val openOrderIntent = Intent(context, MainActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_NAVIGATE_TO, VALUE_ADMIN_ORDERS)
            putExtra(EXTRA_ORDER_ID, orderId)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            orderId.hashCode(),
            openOrderIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Quick action "View Order" button
        val viewAction = NotificationCompat.Action.Builder(
            R.mipmap.ic_launcher,
            "View Order",
            pendingIntent
        ).build()

        // Format items summary lines
        val formattedItems = if (itemsList.isNotEmpty()) {
            itemsList.joinToString(separator = "\n") { item ->
                val variantStr = if (item.variant != null) " (${item.variant})" else ""
                val flavourStr = if (item.flavour != null) " • ${item.flavour}" else ""
                "  • ${item.quantity}x ${item.name}$variantStr$flavourStr"
            }
        } else if (!itemsSummaryText.isNullOrBlank()) {
            "  • $itemsSummaryText"
        } else {
            "  • Delicious Chiya & Snacks"
        }

        val totalQuantity = if (itemsList.isNotEmpty()) itemsList.sumOf { it.quantity } else 1
        val orderLocationMeta = if (orderType.contains("Dine", ignoreCase = true)) {
            if (!tableOrPickup.isNullOrBlank()) "Table #$tableOrPickup" else "Dine-in"
        } else {
            if (!tableOrPickup.isNullOrBlank()) "Pickup: $tableOrPickup" else "Takeaway"
        }

        val shortSummary = "$customerName ordered $totalQuantity item${if (totalQuantity > 1) "s" else ""} • NPR ${subtotal.toInt()}"

        val bigText = StringBuilder().apply {
            append("👤 Customer: $customerName\n")
            append("📋 Items ($totalQuantity total):\n")
            append(formattedItems).append("\n")
            append("💰 Total: NPR ${subtotal.toInt()}\n")
            append("🔖 Order #: $orderId\n")
            append("📍 Service: $orderLocationMeta")
        }.toString()

        val notificationBuilder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("New Order • $orderId")
            .setContentText(shortSummary)
            .setSubText(orderLocationMeta)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .setBigContentTitle("New Order: $customerName (#$orderId)")
                    .setSummaryText("NPR ${subtotal.toInt()} • $orderLocationMeta")
                    .bigText(bigText)
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setVibrate(longArrayOf(0, 350, 150, 350, 150, 450))
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .addAction(viewAction)

        try {
            val appIconBitmap = BitmapFactory.decodeResource(context.resources, R.mipmap.ic_launcher)
            if (appIconBitmap != null) {
                notificationBuilder.setLargeIcon(appIconBitmap)
            }
        } catch (e: Exception) {
            // Ignore large icon load failure
        }

        try {
            NotificationManagerCompat.from(context).notify(orderId.hashCode(), notificationBuilder.build())
            Log.d("OrderNotificationHelper", "Dispatched heads-up notification for order $orderId")
        } catch (e: SecurityException) {
            Log.e("OrderNotificationHelper", "SecurityException: POST_NOTIFICATIONS permission not granted", e)
        } catch (e: Exception) {
            Log.e("OrderNotificationHelper", "Failed to dispatch notification", e)
        }
    }
}
