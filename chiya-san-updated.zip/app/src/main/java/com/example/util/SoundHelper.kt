package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.RingtoneManager
import android.media.ToneGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sin

object SoundHelper {

    fun playOrderChime(context: Context) {
        CoroutineScope(Dispatchers.Default).launch {
            var soundPlayed = false
            try {
                // Synthesize a pleasant two-tone restaurant order chime (G5 784Hz -> C6 1046Hz)
                val sampleRate = 44100
                val duration1 = 0.12 // 120ms
                val duration2 = 0.30 // 300ms
                val numSamples1 = (duration1 * sampleRate).toInt()
                val numSamples2 = (duration2 * sampleRate).toInt()
                val totalSamples = numSamples1 + numSamples2
                val samples = ShortArray(totalSamples)

                // Note 1: 783.99 Hz (G5)
                for (i in 0 until numSamples1) {
                    val time = i.toDouble() / sampleRate
                    val envelope = 1.0 - (i.toDouble() / numSamples1) * 0.3
                    val angle = 2.0 * Math.PI * 783.99 * time
                    val sample = (sin(angle) * envelope * 0.85 * Short.MAX_VALUE).toInt()
                    samples[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }

                // Note 2: 1046.50 Hz (C6)
                for (i in 0 until numSamples2) {
                    val time = i.toDouble() / sampleRate
                    val progress = i.toDouble() / numSamples2
                    val envelope = (1.0 - progress) * (1.0 - progress)
                    val angle = 2.0 * Math.PI * 1046.50 * time
                    val sample = (sin(angle) * envelope * 0.95 * Short.MAX_VALUE).toInt()
                    samples[numSamples1 + i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(totalSamples * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(samples, 0, totalSamples)
                audioTrack.play()
                soundPlayed = true
                delay(500)
                audioTrack.release()
            } catch (e: Throwable) {
                soundPlayed = false
            }

            if (!soundPlayed) {
                try {
                    val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85)
                    toneGen.startTone(ToneGenerator.TONE_PROP_BEEP2, 300)
                } catch (_: Throwable) {
                    try {
                        val notificationUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                        val r = RingtoneManager.getRingtone(context, notificationUri)
                        r?.play()
                    } catch (_: Throwable) {}
                }
            }
        }
    }
}
