package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocalCafe
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.firebase.FirebaseApp
import com.example.ui.components.ChiyaAiChatBottomSheet
import com.example.ui.components.NewOrderBanner
import com.example.ui.components.OrderConfirmationDialog
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AdminLoginScreen
import com.example.ui.screens.CartScreen
import com.example.ui.screens.CheckoutScreen
import com.example.ui.screens.MenuScreen
import com.example.ui.screens.OrderHistoryScreen
import com.example.ui.screens.VisitScreen
import com.example.ui.theme.CardHighlight
import com.example.ui.theme.Charcoal
import com.example.ui.theme.CharcoalMuted
import com.example.ui.theme.ChiyaInputTextStyle
import com.example.ui.theme.ChiyaSanTheme
import com.example.ui.theme.Cream
import com.example.ui.theme.DeepGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.TeaGreen
import com.example.ui.theme.Terracotta
import com.example.ui.theme.WarmWhite
import com.example.ui.theme.WoodBrown
import com.example.ui.theme.chiyaTextFieldColors
import com.example.ui.viewmodel.ChiyaViewModel

class MainActivity : ComponentActivity() {

    private var initialRoute: AppRoute? = null
    private var initialOrderId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            FirebaseApp.initializeApp(this)
        } catch (t: Throwable) {
            // Firebase setup is optional/handled gracefully
        }
        enableEdgeToEdge()

        parseIncomingIntent(intent)

        setContent {
            ChiyaSanTheme {
                MainAppScreen(
                    initialRoute = initialRoute ?: AppRoute.MENU,
                    initialOrderId = initialOrderId
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        parseIncomingIntent(intent)
        setContent {
            ChiyaSanTheme {
                MainAppScreen(
                    initialRoute = initialRoute ?: AppRoute.MENU,
                    initialOrderId = initialOrderId
                )
            }
        }
    }

    private fun parseIncomingIntent(intent: Intent?) {
        if (intent == null) return

        val data: Uri? = intent.data
        val navigateToExtra = intent.getStringExtra("NAVIGATE_TO")
        val orderIdExtra = intent.getStringExtra("ORDER_ID")
        initialOrderId = orderIdExtra

        if (data != null) {
            val path = data.path ?: ""
            val host = data.host ?: ""
            when {
                path.contains("login") || (host == "admin" && path.contains("login")) -> {
                    initialRoute = AppRoute.ADMIN_LOGIN
                }
                path.contains("admin") || host == "admin" -> {
                    initialRoute = AppRoute.ADMIN_DASHBOARD
                }
                path.contains("cart") -> initialRoute = AppRoute.CART
                path.contains("history") -> initialRoute = AppRoute.HISTORY
                path.contains("visit") -> initialRoute = AppRoute.VISIT
                else -> initialRoute = AppRoute.MENU
            }
        } else if (navigateToExtra != null) {
            when (navigateToExtra.trim().uppercase()) {
                "ADMIN", "/ADMIN", "ADMIN_DASHBOARD", "ADMIN_ORDERS" -> initialRoute = AppRoute.ADMIN_DASHBOARD
                "ADMIN_LOGIN", "/ADMIN/LOGIN", "LOGIN" -> initialRoute = AppRoute.ADMIN_LOGIN
                "CART", "/CART" -> initialRoute = AppRoute.CART
                "HISTORY", "/HISTORY" -> initialRoute = AppRoute.HISTORY
                "VISIT", "/VISIT" -> initialRoute = AppRoute.VISIT
                else -> initialRoute = AppRoute.MENU
            }
        }
    }
}

enum class AppRoute(val path: String) {
    MENU("/menu"),
    CART("/cart"),
    CHECKOUT("/checkout"),
    HISTORY("/history"),
    VISIT("/visit"),
    ADMIN_LOGIN("/admin/login"),
    ADMIN_DASHBOARD("/admin")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(
    chiyaViewModel: ChiyaViewModel = viewModel(),
    initialRoute: AppRoute = AppRoute.MENU,
    initialOrderId: String? = null
) {
    var currentRoute by remember { mutableStateOf(initialRoute) }
    var showDirectRouteBar by remember { mutableStateOf(false) }
    var routeInput by remember { mutableStateOf("") }

    val cartCount by chiyaViewModel.cartTotalCount.collectAsState()
    val confirmedOrderId by chiyaViewModel.confirmedOrderId.collectAsState()
    val unseenCount by chiyaViewModel.unseenOrderCount.collectAsState()
    val latestAlert by chiyaViewModel.latestOrderAlert.collectAsState()
    val allOrders by chiyaViewModel.pastOrders.collectAsState()
    val isAdminLoggedIn by chiyaViewModel.isAdminLoggedIn.collectAsState()
    val isAiChatOpen by chiyaViewModel.isAiChatOpen.collectAsState()

    val focusManager = LocalFocusManager.current
    val context = androidx.compose.ui.platform.LocalContext.current

    // Request POST_NOTIFICATIONS on Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        chiyaViewModel.setNotificationsEnabled(isGranted)
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val hasPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasPermission) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // Security Gate Enforcement: If /admin is requested without admin login, redirect to /admin/login
    LaunchedEffect(currentRoute, isAdminLoggedIn) {
        if (currentRoute == AppRoute.ADMIN_DASHBOARD && !isAdminLoggedIn) {
            currentRoute = AppRoute.ADMIN_LOGIN
        }
    }

    LaunchedEffect(initialOrderId, allOrders) {
        if (initialOrderId != null) {
            val matchedOrder = allOrders.find { it.orderId == initialOrderId }
            if (matchedOrder != null) {
                chiyaViewModel.selectAdminOrder(matchedOrder)
            }
        }
    }

    val isCustomerView = currentRoute in listOf(
        AppRoute.MENU,
        AppRoute.CART,
        AppRoute.HISTORY,
        AppRoute.VISIT
    )

    Scaffold(
        topBar = {
            // Optional Direct Route Navigation Bar (allows visiting /admin/login or /admin directly)
            AnimatedVisibility(visible = showDirectRouteBar) {
                Surface(
                    color = WarmWhite,
                    shadowElevation = 4.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = null,
                                    tint = DeepGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Direct Route Navigation",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DeepGreen
                                )
                            }

                            IconButton(
                                onClick = { showDirectRouteBar = false },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close Route Bar",
                                    tint = CharcoalMuted
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = routeInput,
                                onValueChange = { routeInput = it },
                                placeholder = { Text("e.g. /admin/login or /admin") },
                                singleLine = true,
                                textStyle = ChiyaInputTextStyle,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                                keyboardActions = KeyboardActions(
                                    onGo = {
                                        focusManager.clearFocus()
                                        navigateToRoute(routeInput, isAdminLoggedIn) { newRoute ->
                                            currentRoute = newRoute
                                            showDirectRouteBar = false
                                        }
                                    }
                                ),
                                colors = chiyaTextFieldColors(),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("direct_route_text_input")
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            Button(
                                onClick = {
                                    focusManager.clearFocus()
                                    navigateToRoute(routeInput, isAdminLoggedIn) { newRoute ->
                                        currentRoute = newRoute
                                        showDirectRouteBar = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DeepGreen),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("direct_route_go_button")
                            ) {
                                Text("Go", fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TextButton(
                                onClick = {
                                    routeInput = "/admin/login"
                                    currentRoute = AppRoute.ADMIN_LOGIN
                                    showDirectRouteBar = false
                                },
                                modifier = Modifier.testTag("quick_route_admin_login")
                            ) {
                                Text("/admin/login", fontSize = 11.sp, color = DeepGreen, fontWeight = FontWeight.Bold)
                            }

                            TextButton(
                                onClick = {
                                    routeInput = "/admin"
                                    if (isAdminLoggedIn) {
                                        currentRoute = AppRoute.ADMIN_DASHBOARD
                                    } else {
                                        currentRoute = AppRoute.ADMIN_LOGIN
                                    }
                                    showDirectRouteBar = false
                                },
                                modifier = Modifier.testTag("quick_route_admin_dashboard")
                            ) {
                                Text("/admin", fontSize = 11.sp, color = DeepGreen, fontWeight = FontWeight.Bold)
                            }

                            TextButton(
                                onClick = {
                                    routeInput = "/menu"
                                    currentRoute = AppRoute.MENU
                                    showDirectRouteBar = false
                                }
                            ) {
                                Text("/menu", fontSize = 11.sp, color = CharcoalMuted)
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            // Customer navigation only: Menu, Cart, History, Visit (Admin tab strictly excluded)
            if (isCustomerView) {
                NavigationBar(
                    containerColor = WarmWhite,
                    contentColor = DeepGreen,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentRoute == AppRoute.MENU,
                        onClick = { currentRoute = AppRoute.MENU },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.LocalCafe,
                                contentDescription = "Menu"
                            )
                        },
                        label = { Text("Menu", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = DeepGreen,
                            indicatorColor = DeepGreen
                        ),
                        modifier = Modifier.testTag("nav_tab_menu")
                    )

                    NavigationBarItem(
                        selected = currentRoute == AppRoute.CART,
                        onClick = { currentRoute = AppRoute.CART },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (cartCount > 0) {
                                        Badge(
                                            containerColor = Terracotta,
                                            contentColor = Color.White
                                        ) {
                                            Text(text = cartCount.toString(), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ShoppingCart,
                                    contentDescription = "Cart"
                                )
                            }
                        },
                        label = { Text("Cart", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = DeepGreen,
                            indicatorColor = DeepGreen
                        ),
                        modifier = Modifier.testTag("nav_tab_cart")
                    )

                    NavigationBarItem(
                        selected = currentRoute == AppRoute.HISTORY,
                        onClick = { currentRoute = AppRoute.HISTORY },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.ReceiptLong,
                                contentDescription = "History"
                            )
                        },
                        label = { Text("History", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = DeepGreen,
                            indicatorColor = DeepGreen
                        ),
                        modifier = Modifier.testTag("nav_tab_history")
                    )

                    NavigationBarItem(
                        selected = currentRoute == AppRoute.VISIT,
                        onClick = { currentRoute = AppRoute.VISIT },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Place,
                                contentDescription = "Visit"
                            )
                        },
                        label = { Text("Visit", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = DeepGreen,
                            indicatorColor = DeepGreen
                        ),
                        modifier = Modifier.testTag("nav_tab_visit")
                    )
                }
            }
        },
        containerColor = Cream,
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentRoute) {
                AppRoute.MENU -> {
                    MenuScreen(
                        viewModel = chiyaViewModel,
                        onOpenCart = { currentRoute = AppRoute.CART }
                    )
                }
                AppRoute.CART -> {
                    CartScreen(
                        viewModel = chiyaViewModel,
                        onBackToMenu = { currentRoute = AppRoute.MENU },
                        onProceedToCheckout = { currentRoute = AppRoute.CHECKOUT }
                    )
                }
                AppRoute.CHECKOUT -> {
                    CheckoutScreen(
                        viewModel = chiyaViewModel,
                        onBackToCart = { currentRoute = AppRoute.CART },
                        onOrderPlaced = { _ ->
                            // Handled via confirmedOrderId
                        }
                    )
                }
                AppRoute.HISTORY -> {
                    OrderHistoryScreen(viewModel = chiyaViewModel)
                }
                AppRoute.VISIT -> {
                    VisitScreen()
                }
                AppRoute.ADMIN_LOGIN -> {
                    AdminLoginScreen(
                        viewModel = chiyaViewModel,
                        onLoginSuccess = {
                            currentRoute = AppRoute.ADMIN_DASHBOARD
                        },
                        onBackToCustomerView = {
                            currentRoute = AppRoute.MENU
                        }
                    )
                }
                AppRoute.ADMIN_DASHBOARD -> {
                    if (isAdminLoggedIn) {
                        AdminDashboardScreen(
                            viewModel = chiyaViewModel,
                            onLogout = {
                                currentRoute = AppRoute.ADMIN_LOGIN
                            },
                            onBackToCustomerView = {
                                currentRoute = AppRoute.MENU
                            }
                        )
                    } else {
                        AdminLoginScreen(
                            viewModel = chiyaViewModel,
                            onLoginSuccess = {
                                currentRoute = AppRoute.ADMIN_DASHBOARD
                            },
                            onBackToCustomerView = {
                                currentRoute = AppRoute.MENU
                            }
                        )
                    }
                }
            }

            // Real-Time Floating Order Alert Banner
            NewOrderBanner(
                order = latestAlert,
                onViewOrder = { order ->
                    if (isAdminLoggedIn) {
                        currentRoute = AppRoute.ADMIN_DASHBOARD
                        chiyaViewModel.selectAdminOrder(order)
                    } else {
                        currentRoute = AppRoute.ADMIN_LOGIN
                    }
                    chiyaViewModel.dismissLatestAlert()
                },
                onDismiss = {
                    chiyaViewModel.dismissLatestAlert()
                },
                parseItemsCount = { json ->
                    chiyaViewModel.parseOrderItems(json).sumOf { it.quantity }
                },
                modifier = Modifier.align(Alignment.TopCenter)
            )

            // Global Confirmation Dialog
            confirmedOrderId?.let { id ->
                OrderConfirmationDialog(
                    orderId = id,
                    onDismiss = {
                        chiyaViewModel.dismissConfirmation()
                        currentRoute = AppRoute.MENU
                    },
                    onViewHistory = {
                        chiyaViewModel.dismissConfirmation()
                        currentRoute = AppRoute.HISTORY
                    }
                )
            }

            // AI Assistant Floating Action Button (for Menu & Customer navigation)
            if (isCustomerView && currentRoute == AppRoute.MENU) {
                FloatingActionButton(
                    onClick = { chiyaViewModel.setAiChatOpen(true) },
                    containerColor = DeepGreen,
                    contentColor = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 16.dp, bottom = if (cartCount > 0) 80.dp else 16.dp)
                        .testTag("open_ai_chat_fab")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Chiya San AI Assistant",
                            tint = TeaGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "AI Guide",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White
                        )
                    }
                }
            }

            // Chiya San AI Assistant Chat Sheet
            if (isAiChatOpen) {
                ChiyaAiChatBottomSheet(
                    viewModel = chiyaViewModel,
                    onDismiss = { chiyaViewModel.setAiChatOpen(false) }
                )
            }

            // Discreet direct route URL activator button (floats in top right corner of customer view for route testing)
            if (isCustomerView && !showDirectRouteBar) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 10.dp, end = 12.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(DeepGreen.copy(alpha = 0.12f))
                        .clickable { showDirectRouteBar = true }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("open_route_bar_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = "Open Route Navigator",
                            tint = DeepGreen,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = currentRoute.path,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = DeepGreen
                        )
                    }
                }
            }
        }
    }
}

private fun navigateToRoute(
    input: String,
    isAdminLoggedIn: Boolean,
    onNavigate: (AppRoute) -> Unit
) {
    val clean = input.trim().lowercase()
    when {
        clean == "/admin/login" || clean == "admin/login" || clean == "login" -> {
            onNavigate(AppRoute.ADMIN_LOGIN)
        }
        clean == "/admin" || clean == "admin" -> {
            if (isAdminLoggedIn) {
                onNavigate(AppRoute.ADMIN_DASHBOARD)
            } else {
                onNavigate(AppRoute.ADMIN_LOGIN)
            }
        }
        clean == "/cart" || clean == "cart" -> onNavigate(AppRoute.CART)
        clean == "/checkout" || clean == "checkout" -> onNavigate(AppRoute.CHECKOUT)
        clean == "/history" || clean == "history" -> onNavigate(AppRoute.HISTORY)
        clean == "/visit" || clean == "visit" -> onNavigate(AppRoute.VISIT)
        else -> onNavigate(AppRoute.MENU)
    }
}
