package com.example.service

import android.content.Context
import android.util.Log
import com.example.data.local.ChiyaDatabase
import com.example.data.local.OrderEntity
import com.example.data.model.OrderItemSummary
import com.example.data.remote.FirestoreOrderService
import com.example.util.OrderNotificationHelper
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Firebase Cloud Messaging Service for handling incoming Admin Push Notifications
 * even when the app is in the background or closed.
 */
class ChiyaFirebaseMessagingService : FirebaseMessagingService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val firestoreService = FirestoreOrderService()
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val listType = Types.newParameterizedType(List::class.java, OrderItemSummary::class.java)
    private val jsonAdapter = moshi.adapter<List<OrderItemSummary>>(listType)

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "New Firebase Messaging Token received: $token")
        val prefs = getSharedPreferences("chiya_fcm_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("fcm_token", token).apply()

        serviceScope.launch {
            firestoreService.saveAdminFcmToken(token)
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(TAG, "FCM Message received from: ${remoteMessage.from}")

        val data = remoteMessage.data
        if (data.isNotEmpty()) {
            val orderId = data["order_id"] ?: data["orderId"] ?: "CS-${System.currentTimeMillis() % 10000}"
            val customerName = data["customer_name"] ?: data["customerName"] ?: "Customer"
            val customerPhone = data["customer_phone"] ?: data["customerPhone"] ?: ""
            val orderType = data["order_type"] ?: data["orderType"] ?: "Dine-in"
            val tableNumber = data["table_number"] ?: data["tableNumber"]
            val pickupTime = data["pickup_time"] ?: data["pickupTime"]
            val itemsJson = data["items_summary_json"] ?: data["items_json"] ?: "[]"
            val itemsSummaryText = data["items_summary"] ?: data["items"]
            val subtotal = data["subtotal"]?.toDoubleOrNull() ?: data["total_price"]?.toDoubleOrNull() ?: 0.0
            val discount = data["discount"]?.toDoubleOrNull() ?: 0.0
            val tax = data["tax"]?.toDoubleOrNull() ?: 0.0
            val serviceCharge = data["service_charge"]?.toDoubleOrNull() ?: 0.0
            val totalPrice = data["total_price"]?.toDoubleOrNull() ?: (subtotal - discount + tax + serviceCharge)
            val paymentMethod = data["payment_method"] ?: "Pay at Counter (Cash / QR)"
            val paymentStatus = data["payment_status"] ?: "Pending"
            val receiptNumber = data["receipt_number"] ?: orderId

            val itemsList = try {
                jsonAdapter.fromJson(itemsJson) ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }

            // Show rich heads-up push notification
            OrderNotificationHelper.showNewOrderPushNotification(
                context = applicationContext,
                orderId = orderId,
                customerName = customerName,
                subtotal = totalPrice,
                itemsList = itemsList,
                itemsSummaryText = itemsSummaryText,
                orderType = orderType,
                tableOrPickup = tableNumber ?: pickupTime
            )

            // Sync to local Room database in background
            serviceScope.launch {
                try {
                    val db = ChiyaDatabase.getDatabase(applicationContext)
                    val existingOrder = db.orderDao().getOrderById(orderId)
                    if (existingOrder == null) {
                        val newEntity = OrderEntity(
                            orderId = orderId,
                            customerName = customerName,
                            customerPhone = customerPhone,
                            orderType = orderType,
                            tableNumber = tableNumber,
                            pickupTime = pickupTime,
                            itemsSummaryJson = itemsJson,
                            subtotal = totalPrice,
                            timestamp = System.currentTimeMillis(),
                            status = "Order Placed (Pay at Counter)",
                            trackingToken = ""
                        )
                        db.orderDao().insertOrder(newEntity)
                        Log.d(TAG, "Synced incoming background push order $orderId into local Room DB.")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error saving push order to Room: ${e.message}", e)
                }
            }
        } else {
            // Notification payload fallback
            remoteMessage.notification?.let { notification ->
                val title = notification.title ?: "New Order"
                val body = notification.body ?: "A new order was placed"
                OrderNotificationHelper.showNewOrderPushNotification(
                    context = applicationContext,
                    orderId = "CS-LIVE",
                    customerName = title,
                    subtotal = 0.0,
                    itemsSummaryText = body
                )
            }
        }
    }

    companion object {
        private const val TAG = "ChiyaFcmService"
    }
}
