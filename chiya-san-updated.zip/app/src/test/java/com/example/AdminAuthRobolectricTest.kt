package com.example

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.AdminAuthRepository
import com.example.ui.viewmodel.ChiyaViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AdminAuthRobolectricTest {

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `initial auth state is unauthenticated`() = runTest(testDispatcher) {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val repo = AdminAuthRepository(app)

        assertFalse(repo.isAuthenticatedAdmin.value)
        assertNull(repo.currentSession.value)
    }

    @Test
    fun `invalid email format rejects instantly with clear error`() = runTest(testDispatcher) {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val repo = AdminAuthRepository(app)

        val result = repo.loginAdmin("invalid-email", "secretPassword123")
        advanceUntilIdle()

        assertTrue(result.isFailure)
        assertFalse(repo.isAuthenticatedAdmin.value)
        assertEquals("Please enter a valid email address.", repo.authError.value)
    }

    @Test
    fun `short password on login is rejected`() = runTest(testDispatcher) {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val repo = AdminAuthRepository(app)

        val result = repo.loginAdmin("admin@chiyasan.com", "123")
        advanceUntilIdle()

        assertTrue(result.isFailure)
        assertEquals("Password must be at least 6 characters.", repo.authError.value)
    }

    @Test
    fun `viewModel logout cleans state appropriately`() = runTest(testDispatcher) {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = ChiyaViewModel(app)

        viewModel.logoutAdmin()
        advanceUntilIdle()

        assertFalse(viewModel.isAdminLoggedIn.value)
        assertNull(viewModel.currentAdminSession.value)
        assertFalse(viewModel.revealCustomerPhone.value)
    }
}
