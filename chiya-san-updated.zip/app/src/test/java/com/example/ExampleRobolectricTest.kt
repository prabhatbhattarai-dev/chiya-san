package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.MenuItem
import com.example.ui.viewmodel.ChiyaViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Chiya San", appName)
    }

    @Test
    fun `order placement triggers real-time unseen order state`() = runTest(testDispatcher) {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = ChiyaViewModel(app)

        advanceUntilIdle()

        // Verify initial state
        assertEquals(0, viewModel.cartTotalCount.value)

        // Select category and update search
        viewModel.selectCategory("Tea")
        assertEquals("Tea", viewModel.selectedCategory.value)

        viewModel.updateSearchQuery("Masala")
        assertEquals("Masala", viewModel.searchQuery.value)

        // Verify admin status filter
        viewModel.setAdminStatusFilter("Pending")
        assertEquals("Pending", viewModel.adminStatusFilter.value)

        // Direct mark as seen test
        viewModel.markOrderAsSeen("test-order-123")
        assertEquals(0, viewModel.unseenOrderCount.value)
    }
}
