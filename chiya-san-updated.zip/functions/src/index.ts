import { onDocumentCreated } from "firebase-functions/v2/firestore";
import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { getMessaging } from "firebase-admin/messaging";

initializeApp();

const db = getFirestore();

/**
 * Sends a push notification to every registered admin device whenever a
 * customer creates a new Firestore order. This is the missing server-side
 * bridge that allows the cafe team to receive the order even when the
 * admin app is in the background or completely closed.
 */
export const notifyAdminsOnNewOrder = onDocumentCreated("orders/{orderId}", async (event) => {
  const snap = event.data;
  if (!snap) return;

  const order = snap.data();
  const orderId = String(order.orderId ?? event.params.orderId);
  const customerName = String(order.customerName ?? "Customer");
  const orderType = String(order.orderType ?? "Dine-in");
  const tableNumber = String(order.tableNumber ?? "");
  const pickupTime = String(order.pickupTime ?? "");
  const subtotal = Number(order.subtotal ?? 0);
  const discount = Number(order.discount ?? 0);
  const tax = Number(order.tax ?? 0);
  const serviceCharge = Number(order.serviceCharge ?? 0);
  const total = Number(order.total ?? (subtotal - discount + tax + serviceCharge));
  const paymentMethod = String(order.paymentMethod ?? "Pay at Counter (Cash / QR)");
  const paymentStatus = String(order.paymentStatus ?? "Pending");
  const receiptNumber = String(order.receiptNumber ?? orderId);

  let itemsSummary = String(order.itemsSummaryJson ?? "[]");
  try {
    const parsed = JSON.parse(itemsSummary);
    if (Array.isArray(parsed)) {
      itemsSummary = parsed.map((item: any) => {
        const variant = item.variant ? ` (${item.variant})` : "";
        const flavour = item.flavour ? ` • ${item.flavour}` : "";
        return `${item.quantity ?? 1}x ${item.name ?? "Item"}${variant}${flavour}`;
      }).join("\n");
    }
  } catch {
    // Keep the original value if parsing fails.
  }

  const tokensSnap = await db.collection("admin_fcm_tokens").get();
  const tokens = tokensSnap.docs
    .map((doc) => String(doc.get("token") ?? doc.id))
    .filter(Boolean);

  if (tokens.length === 0) {
    console.warn("No admin FCM tokens registered.");
    return;
  }

  const location = orderType.toLowerCase().includes("dine")
    ? `Table #${tableNumber || "?"}`
    : `Pickup: ${pickupTime || "ASAP"}`;

  const message = {
    tokens,
    notification: {
      title: `New Cafe Order • ${orderId}`,
      body: `${customerName} • ${location} • NPR ${total.toFixed(0)}`
    },
    data: {
      order_id: orderId,
      customer_name: customerName,
      customer_phone: String(order.customerPhone ?? ""),
      order_type: orderType,
      table_number: tableNumber,
      pickup_time: pickupTime,
      items_summary_json: String(order.itemsSummaryJson ?? "[]"),
      items_summary: itemsSummary,
      subtotal: String(subtotal),
      discount: String(discount),
      tax: String(tax),
      service_charge: String(serviceCharge),
      total_price: String(total),
      payment_method: paymentMethod,
      payment_status: paymentStatus,
      receipt_number: receiptNumber
    },
    android: {
      priority: "high" as const,
      notification: {
        channelId: "chiya_admin_orders_channel",
        sound: "default"
      }
    }
  };

  const response = await getMessaging().sendEachForMulticast(message);
  console.log(`Order ${orderId}: sent ${response.successCount}/${tokens.length} admin notifications.`);

  // Remove invalid/stale FCM tokens so future orders do not keep retrying them.
  const staleTokenDocs = tokensSnap.docs.filter((doc) => {
    const token = String(doc.get("token") ?? doc.id);
    const idx = tokens.indexOf(token);
    return idx >= 0 && response.responses[idx]?.success === false;
  });

  if (staleTokenDocs.length > 0) {
    const batch = db.batch();
    for (const doc of staleTokenDocs) {
      batch.delete(doc.ref);
    }
    await batch.commit();
  }

  await snap.ref.set({
    notificationDispatchedAt: FieldValue.serverTimestamp(),
    notificationSuccessCount: response.successCount,
    notificationFailureCount: response.failureCount
  }, { merge: true });
});
