# Chiya San order notification backend

The Android app already registers each admin device's FCM token in
`admin_fcm_tokens` and saves customer orders to the Firestore `orders`
collection.

This Firebase Function completes the missing piece:

`Customer places order -> Firestore order created -> Cloud Function -> FCM -> every admin device`

That means the cafe team can receive a push notification even when the admin
app is in the background or closed.

## Deploy

1. Install Node.js 20 and Firebase CLI.
2. From the project root, run `firebase login`.
3. Select your Firebase project with `firebase use <YOUR_FIREBASE_PROJECT_ID>`.
4. Run:
   `cd functions`
   `npm install`
   `npm run build`
   `cd ..`
   `firebase deploy --only functions`
5. Make sure the Android app is connected to the same Firebase project and that
   the Firebase Messaging/Firestore configuration is present.
6. Log into the admin screen once on every cafe device and tap **Enable Alerts**.

## Important

- Do not put a Firebase service-account JSON file inside the Android app.
- Keep Firestore security rules configured so only authorized admin devices can
  write/read `admin_fcm_tokens`.
- The VAT rate is configured in
  `app/src/main/java/com/example/data/model/BillingConfig.kt`. The default is
  13% for a VAT-registered Nepal cafe; set it to 0.0 if the cafe should not
  charge VAT.
- Online payments such as Khalti/eSewa still require the cafe's merchant
  credentials and a payment verification callback. The current checkout uses
  Pay at Counter (Cash / QR) and records payment status.
