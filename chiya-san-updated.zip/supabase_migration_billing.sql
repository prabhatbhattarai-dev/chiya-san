-- Run this once against the existing Supabase `orders` table.
-- Safe for existing orders because every new field has a default.

alter table public.orders
  add column if not exists discount numeric(12,2) not null default 0,
  add column if not exists tax numeric(12,2) not null default 0,
  add column if not exists service_charge numeric(12,2) not null default 0,
  add column if not exists total numeric(12,2) not null default 0,
  add column if not exists payment_method text not null default 'Pay at Counter (Cash / QR)',
  add column if not exists payment_status text not null default 'Pending',
  add column if not exists receipt_number text;

-- Backfill the new total/receipt fields for existing orders.
update public.orders
set total = subtotal + tax + service_charge - discount
where total = 0;

update public.orders
set receipt_number = order_id
where receipt_number is null;

-- Recommended index for the admin kitchen feed.
create index if not exists orders_timestamp_desc_idx
  on public.orders (timestamp desc);
