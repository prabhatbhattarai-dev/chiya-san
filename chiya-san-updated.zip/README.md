<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/bbb7c950-aaa5-4c59-ae7b-4a35690ff94c

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.


## Cafe ordering, billing & real-time staff alerts

The project now includes:

- Real-time order persistence through Firestore/Supabase.
- Admin push notifications for new orders through Firebase Cloud Messaging.
- A Firebase Cloud Function that sends the order to every registered admin device,
  including when the admin app is closed.
- Order lifecycle: New → Accepted → Preparing → Ready → Completed / Cancelled.
- Billing breakdown: subtotal, discount, VAT, service charge and final payable total.
- Payment method/status tracking and receipt number.
- Admin controls for Pending / Paid / Refunded / Failed payment states.
- Customer order history with the final billed total.
- A Supabase migration file: `supabase_migration_billing.sql`.

### One-time backend setup

For notifications to work across different phones, the Firebase Function in
`functions/` must be deployed. The Android app alone cannot send a push message
to another device securely.

See `functions/README.md` for deployment steps. Also run
`supabase_migration_billing.sql` if your Supabase `orders` table does not yet
contain the billing columns.

### Tax configuration

`BillingConfig.kt` controls VAT and service charge. The default VAT is 13% for a
VAT-registered Nepal cafe. If the cafe is not VAT registered, set
`VAT_RATE = 0.0` before production use. Service charge is 0% by default.

### Important payment note

The current implementation records **Pay at Counter (Cash / QR)** and tracks
whether the bill is Pending/Paid/Refunded/Failed. Khalti/eSewa online payment
needs the cafe's own merchant account and server-side payment verification before
it should be enabled.
